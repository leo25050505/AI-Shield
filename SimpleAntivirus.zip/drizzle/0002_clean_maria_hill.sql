CREATE TABLE `urlDetectionResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`url` varchar(2048) NOT NULL,
	`threatLevel` enum('safe','suspicious','dangerous') NOT NULL,
	`threatDescription` text,
	`threatCategories` text,
	`detectionSource` varchar(100) NOT NULL,
	`detectionTime` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `urlDetectionResults_id` PRIMARY KEY(`id`)
);
