CREATE TABLE `scanHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`totalScans` int NOT NULL,
	`safeCount` int NOT NULL DEFAULT 0,
	`suspiciousCount` int NOT NULL DEFAULT 0,
	`dangerousCount` int NOT NULL DEFAULT 0,
	`overallRiskLevel` enum('safe','suspicious','dangerous') NOT NULL,
	`scanStartTime` timestamp NOT NULL,
	`scanEndTime` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `scanHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scanResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileSize` int NOT NULL,
	`fileType` varchar(100) NOT NULL,
	`fileHash` varchar(64),
	`threatLevel` enum('safe','suspicious','dangerous') NOT NULL,
	`threatDescription` text,
	`scanTime` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `scanResults_id` PRIMARY KEY(`id`)
);
