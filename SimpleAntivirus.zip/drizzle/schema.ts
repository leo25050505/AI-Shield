import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Scan results table: stores each file scan result
 */
export const scanResults = mysqlTable("scanResults", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileSize: int("fileSize").notNull(), // in bytes
  fileType: varchar("fileType", { length: 100 }).notNull(),
  fileHash: varchar("fileHash", { length: 64 }), // SHA-256 hash
  threatLevel: mysqlEnum("threatLevel", ["safe", "suspicious", "dangerous"]).notNull(),
  threatDescription: text("threatDescription"),
  scanTime: timestamp("scanTime").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ScanResult = typeof scanResults.$inferSelect;
export type InsertScanResult = typeof scanResults.$inferInsert;

/**
 * Scan history table: tracks scan sessions
 */
export const scanHistory = mysqlTable("scanHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  totalScans: int("totalScans").notNull(),
  safeCount: int("safeCount").notNull().default(0),
  suspiciousCount: int("suspiciousCount").notNull().default(0),
  dangerousCount: int("dangerousCount").notNull().default(0),
  overallRiskLevel: mysqlEnum("overallRiskLevel", ["safe", "suspicious", "dangerous"]).notNull(),
  scanStartTime: timestamp("scanStartTime").notNull(),
  scanEndTime: timestamp("scanEndTime").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ScanHistory = typeof scanHistory.$inferSelect;
export type InsertScanHistory = typeof scanHistory.$inferInsert;

/**
 * URL detection results table: stores URL threat analysis
 */
export const urlDetectionResults = mysqlTable("urlDetectionResults", {
  id: int("id").autoincrement().primaryKey(),
  url: varchar("url", { length: 2048 }).notNull(),
  threatLevel: mysqlEnum("threatLevel", ["safe", "suspicious", "dangerous"]).notNull(),
  threatDescription: text("threatDescription"),
  threatCategories: text("threatCategories"), // JSON array of threat types
  detectionSource: varchar("detectionSource", { length: 100 }).notNull(), // e.g., "google_safe_browsing"
  detectionTime: timestamp("detectionTime").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UrlDetectionResult = typeof urlDetectionResults.$inferSelect;
export type InsertUrlDetectionResult = typeof urlDetectionResults.$inferInsert;
