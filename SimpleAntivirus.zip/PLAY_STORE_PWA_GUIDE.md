# Google Play Store PWA 發佈指南

## AI極簡防護 - PWA 版本發佈

本指南將帶您逐步在 Google Play Store 發佈 AI極簡防護 PWA 應用。

---

## 📋 前置準備

### 1. Google Play Developer 帳戶
- 訪問：https://play.google.com/console
- 支付 $25 USD 開發者費用（一次性）
- 設定開發者帳戶信息

### 2. 準備資料
- 應用名稱：**AI極簡防護**
- 應用描述：AI 驅動的極簡防毒掃描工具
- 應用圖標：512x512 PNG 圖片
- 應用截圖：至少 2 張（1080x1920 或更大）
- 隱私政策 URL：需要一個公開的隱私政策頁面

---

## 🚀 發佈步驟

### 步驟 1：建立新應用

1. 登入 [Google Play Console](https://play.google.com/console)
2. 點擊「建立應用」
3. 填寫應用信息：
   - **應用名稱**：AI極簡防護
   - **預設語言**：繁體中文
   - **應用或遊戲**：選擇「應用」
   - **免費或付費**：選擇「免費」

### 步驟 2：填寫應用詳細信息

在左側菜單選擇「應用詳細信息」：

**基本信息**
- 應用類別：工具
- 內容分級：填寫問卷
- 聯絡電郵：您的郵箱

**隱私政策**
- 隱私政策 URL：https://simpleav-jjwqgsqi.manus.space/privacy （需要建立）

**應用圖標**
- 上傳 512x512 PNG 圖片

### 步驟 3：建立隱私政策頁面

在您的應用中新增隱私政策頁面：

```html
<!-- 在 client/src/pages/PrivacyPolicy.tsx 中 -->
<div className="privacy-policy">
  <h1>隱私政策</h1>
  <h2>資料收集</h2>
  <p>AI極簡防護掃描檔案時，僅在本地進行分析，不會上傳任何個人資料到遠端伺服器。</p>
  
  <h2>資料使用</h2>
  <p>掃描結果僅儲存在您的設備上，用於生成掃描歷史記錄。</p>
  
  <h2>第三方服務</h2>
  <p>應用使用 ClamAV 防毒引擎進行本地掃描。</p>
  
  <h2>聯絡我們</h2>
  <p>如有隱私相關問題，請聯絡：your-email@example.com</p>
</div>
```

### 步驟 4：上傳應用截圖

在「應用截圖」部分上傳至少 2 張截圖：
- 手機截圖（1080x1920 或 1440x2560）
- 建議上傳 4-5 張展示主要功能

**截圖建議**
1. 首頁 - 檔案上傳區域
2. 掃描結果 - 威脅等級顯示
3. URL 檢測 - URL 輸入與結果
4. 掃描歷史 - 歷史記錄清單

### 步驟 5：建立應用發佈

在左側菜單選擇「版本」 → 「建立新版本」：

**選擇發佈類型**
- 選擇「內部測試」或「測試版」進行初期測試
- 確認無誤後發佈到「正式版」

**版本信息**
- 版本號：1.0.0
- 版本名稱：初始版本
- 發佈說明：
  ```
  AI極簡防護 - 一鍵式防毒掃描工具
  
  功能：
  • 檔案掃毒 - 使用 ClamAV 引擎進行威脅分析
  • URL 檢測 - 檢測網址是否含有惡意內容
  • 掃描歷史 - 自動記錄所有掃描結果
  • 極簡設計 - 深色科技風介面
  
  完全免費，無廣告，無需登入。
  ```

### 步驟 6：設定應用簽名

由於這是 PWA 應用，無需傳統的 APK 簽名。但需要設定應用簽名密鑰：

1. 在「版本」中選擇「應用簽名」
2. 選擇「Google Play 應用簽名」（推薦）
3. Google Play 會自動管理簽名

### 步驟 7：設定內容分級

1. 選擇「內容分級」
2. 填寫問卷（通常評為「全年齡」）
3. 提交問卷

### 步驟 8：設定隱私權和權限

1. 選擇「隱私」
2. 聲明應用權限：
   - 不收集個人資料
   - 不追蹤用戶
   - 不共享資料給第三方

### 步驟 9：上傳 APK 或 AAB

**對於 PWA，您有兩個選項：**

**選項 A：使用 Trusted Web Activity (TWA)**
- 這是 Google 推薦的方式
- 將 PWA 包裝成原生 Android 應用
- 需要生成 TWA APK

**選項 B：使用 Web Wrapper**
- 更簡單的方式
- 直接在 WebView 中運行 PWA

**推薦使用選項 A（TWA）**

### 步驟 10：生成 TWA APK

使用 Google 提供的工具生成 TWA APK：

```bash
# 安裝 TWA CLI
npm install -g @bubblewrap/cli

# 初始化 TWA 專案
bubblewrap init \
  --manifest https://simpleav-jjwqgsqi.manus.space/manifest.json \
  --package-id com.aishield.antivirus \
  --app-name "AI極簡防護"

# 構建 APK
bubblewrap build

# 構建 AAB（推薦用於 Play Store）
bubblewrap build --aab
```

生成的 AAB 檔案位置：`./app-release.aab`

### 步驟 11：上傳 AAB 到 Play Store

1. 在 Google Play Console 中選擇「版本」
2. 點擊「建立新版本」
3. 上傳 `app-release.aab` 檔案
4. 填寫版本信息
5. 檢查所有內容
6. 提交審核

### 步驟 12：等待審核

- Google Play 通常在 24-48 小時內審核應用
- 審核通過後，應用將在 Play Store 上線
- 您可以在 Google Play Console 追蹤審核進度

---

## 📱 應用在 Play Store 上線後

### 推廣
- 在應用商店頁面添加應用連結
- 在社交媒體分享應用
- 收集用戶評論和反饋

### 更新
- 定期更新應用版本
- 修復 Bug 和添加新功能
- 在 Play Store 上發佈更新

### 監控
- 查看下載量和評分
- 分析用戶反饋
- 改進應用功能

---

## 🔧 常見問題

### Q: PWA 和原生應用有什麼區別？
A: PWA 可以在瀏覽器中運行，也可以安裝為應用。原生應用性能更好，但開發時間更長。

### Q: 為什麼選擇 TWA？
A: TWA 是 Google 推薦的方式，可以將 PWA 發佈到 Play Store，無需開發原生應用。

### Q: 應用審核會被拒絕嗎？
A: 只要遵守 Google Play 政策，通常不會被拒絕。常見拒絕原因包括：
- 隱私政策不完整
- 應用功能不完整
- 違反 Google Play 政策

### Q: 如何更新應用？
A: 在 Google Play Console 中上傳新版本的 AAB，填寫更新說明，提交審核即可。

---

## 📞 聯絡支援

如有問題，請參考：
- [Google Play Console 幫助](https://support.google.com/googleplay/android-developer)
- [TWA 文檔](https://developer.chrome.com/docs/android/trusted-web-activity/)
- [PWA 文檔](https://web.dev/progressive-web-apps/)

---

## ✅ 檢查清單

發佈前請確認：

- [ ] Google Play Developer 帳戶已建立
- [ ] 應用圖標已準備（512x512 PNG）
- [ ] 應用截圖已準備（至少 2 張）
- [ ] 隱私政策頁面已建立
- [ ] 應用描述已填寫
- [ ] 內容分級已完成
- [ ] TWA APK/AAB 已生成
- [ ] 所有信息已檢查
- [ ] 提交審核

---

**祝您發佈成功！🎉**
