import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, scanResults, InsertScanResult, scanHistory, InsertScanHistory, urlDetectionResults, InsertUrlDetectionResult } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Create a new scan result
 */
export async function createScanResult(result: InsertScanResult) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const inserted = await db.insert(scanResults).values(result);
  return inserted;
}

/**
 * Get scan results by user ID
 */
export async function getScanResultsByUserId(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const results = await db
    .select()
    .from(scanResults)
    .where(eq(scanResults.userId, userId))
    .orderBy(desc(scanResults.scanTime))
    .limit(limit);
  
  return results;
}

/**
 * Get scan history by user ID
 */
export async function getScanHistoryByUserId(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const history = await db
    .select()
    .from(scanHistory)
    .where(eq(scanHistory.userId, userId))
    .orderBy(desc(scanHistory.scanEndTime))
    .limit(limit);
  
  return history;
}

/**
 * Create scan history record
 */
export async function createScanHistory(history: InsertScanHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const inserted = await db.insert(scanHistory).values(history);
  return inserted;
}

/**
 * Get single scan result by ID
 */
export async function getScanResultById(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db
    .select()
    .from(scanResults)
    .where(eq(scanResults.id, id))
    .limit(1);
  
  // Verify user ownership
  if (result.length > 0 && result[0].userId !== userId) {
    throw new Error("Unauthorized");
  }
  
  return result.length > 0 ? result[0] : null;
}


/**
 * Create URL detection result
 */
export async function createUrlDetectionResult(result: InsertUrlDetectionResult) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const inserted = await db.insert(urlDetectionResults).values(result);
  return inserted;
}

/**
 * Get URL detection results (recent detections)
 */
export async function getUrlDetectionResults(limit = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const results = await db
    .select()
    .from(urlDetectionResults)
    .orderBy(desc(urlDetectionResults.detectionTime))
    .limit(limit);
  
  return results;
}

/**
 * Get URL detection result by URL
 */
export async function getUrlDetectionByUrl(url: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db
    .select()
    .from(urlDetectionResults)
    .where(eq(urlDetectionResults.url, url))
    .orderBy(desc(urlDetectionResults.detectionTime))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}
