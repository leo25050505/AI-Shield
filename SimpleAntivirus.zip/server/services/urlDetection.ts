import axios from "axios";

export interface UrlThreatInfo {
  threatLevel: "safe" | "suspicious" | "dangerous";
  threatDescription: string;
  threatCategories: string[];
}

/**
 * Detect URL threats using heuristic analysis
 * This is a fallback when external APIs are unavailable
 */
export function detectUrlThreatHeuristic(url: string): UrlThreatInfo {
  const lowerUrl = url.toLowerCase();
  
  // Dangerous patterns
  const dangerousPatterns = [
    /bit\.ly|tinyurl|short\.link/i, // URL shorteners (often used for phishing)
    /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i, // IP addresses (suspicious)
    /[a-z0-9]{32,}/i, // Long random strings (often malicious)
  ];
  
  // Suspicious patterns
  const suspiciousPatterns = [
    /phishing|malware|trojan|virus|worm/i,
    /admin|login|signin|verify|confirm/i, // Common phishing keywords
    /download|install|update|plugin/i,
    /\.tk|\.ml|\.ga|\.cf/i, // Free domain TLDs
  ];
  
  // Check dangerous patterns
  for (const pattern of dangerousPatterns) {
    if (pattern.test(lowerUrl)) {
      return {
        threatLevel: "dangerous",
        threatDescription: "URL contains suspicious patterns commonly associated with malware or phishing attacks",
        threatCategories: ["MALWARE", "PHISHING"],
      };
    }
  }
  
  // Check suspicious patterns
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(lowerUrl)) {
      return {
        threatLevel: "suspicious",
        threatDescription: "URL contains patterns that may indicate phishing or social engineering",
        threatCategories: ["PHISHING", "SOCIAL_ENGINEERING"],
      };
    }
  }
  
  // Check for HTTPS
  if (!lowerUrl.startsWith("https://")) {
    return {
      threatLevel: "suspicious",
      threatDescription: "URL does not use HTTPS encryption - potential security risk",
      threatCategories: ["INSECURE_CONNECTION"],
    };
  }
  
  return {
    threatLevel: "safe",
    threatDescription: "URL appears to be safe based on heuristic analysis",
    threatCategories: [],
  };
}

/**
 * Detect URL threats using VirusTotal API
 * Requires VIRUSTOTAL_API_KEY environment variable
 */
export async function detectUrlThreatVirusTotal(url: string): Promise<UrlThreatInfo> {
  const apiKey = process.env.VIRUSTOTAL_API_KEY;
  
  if (!apiKey) {
    console.warn("[UrlDetection] VirusTotal API key not configured, using heuristic analysis");
    return detectUrlThreatHeuristic(url);
  }
  
  try {
    // VirusTotal API v3
    const response = await axios.post(
      "https://www.virustotal.com/api/v3/urls",
      `url=${encodeURIComponent(url)}`,
      {
        headers: {
          "x-apikey": apiKey,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        timeout: 10000,
      }
    );
    
    const analysisId = response.data.data.id;
    
    // Get analysis results
    const analysisResponse = await axios.get(
      `https://www.virustotal.com/api/v3/analyses/${analysisId}`,
      {
        headers: { "x-apikey": apiKey },
        timeout: 10000,
      }
    );
    
    const stats = analysisResponse.data.data.attributes.stats;
    const maliciousCount = stats.malicious || 0;
    const suspiciousCount = stats.suspicious || 0;
    
    // Determine threat level
    let threatLevel: "safe" | "suspicious" | "dangerous" = "safe";
    let threatCategories: string[] = [];
    
    if (maliciousCount > 0) {
      threatLevel = "dangerous";
      threatCategories = ["MALWARE", "PHISHING", "TROJAN"];
    } else if (suspiciousCount > 0) {
      threatLevel = "suspicious";
      threatCategories = ["SUSPICIOUS"];
    }
    
    return {
      threatLevel,
      threatDescription: `VirusTotal scan: ${maliciousCount} malicious, ${suspiciousCount} suspicious detections`,
      threatCategories,
    };
  } catch (error) {
    console.error("[UrlDetection] VirusTotal API error:", error);
    // Fallback to heuristic analysis
    return detectUrlThreatHeuristic(url);
  }
}

/**
 * Main URL detection function
 * Uses VirusTotal API if available, falls back to heuristic analysis
 */
export async function detectUrlThreat(url: string): Promise<UrlThreatInfo> {
  // Validate URL format
  try {
    new URL(url);
  } catch {
    return {
      threatLevel: "suspicious",
      threatDescription: "Invalid URL format",
      threatCategories: ["INVALID_URL"],
    };
  }
  
  // Try VirusTotal first
  if (process.env.VIRUSTOTAL_API_KEY) {
    return await detectUrlThreatVirusTotal(url);
  }
  
  // Fallback to heuristic analysis
  return detectUrlThreatHeuristic(url);
}
