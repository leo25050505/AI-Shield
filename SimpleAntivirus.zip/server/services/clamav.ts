import { exec } from "child_process";
import { promisify } from "util";
import * as fs from "fs";
import * as path from "path";

const execAsync = promisify(exec);

/**
 * ClamAV 掃描結果
 */
export interface ClamAVResult {
  isInfected: boolean;
  threatName?: string;
  details: string;
}

/**
 * 使用 ClamAV 掃描檔案
 */
export async function scanFileWithClamAV(
  filePath: string
): Promise<ClamAVResult> {
  try {
    // 檢查檔案是否存在
    if (!fs.existsSync(filePath)) {
      return {
        isInfected: false,
        details: "File not found",
      };
    }

    // 執行 clamscan 命令
    const { stdout, stderr } = await execAsync(`clamscan "${filePath}"`, {
      timeout: 30000, // 30 秒超時
    });

    // 解析掃描結果
    // ClamAV 輸出格式: "file: FOUND" 或 "file: OK"
    const output = stdout + stderr;

    if (output.includes("FOUND")) {
      // 提取威脅名稱
      const threatMatch = output.match(/:\s*(.+?)\s+FOUND/);
      const threatName = threatMatch ? threatMatch[1] : "Unknown threat";

      return {
        isInfected: true,
        threatName: threatName,
        details: `Threat detected: ${threatName}`,
      };
    }

    return {
      isInfected: false,
      details: "File is clean",
    };
  } catch (error: any) {
    // 如果 clamscan 返回非零退出碼，表示檢測到威脅
    if (error.code === 1) {
      const output = error.stdout || error.stderr || "";
      const threatMatch = output.match(/:\s*(.+?)\s+FOUND/);
      const threatName = threatMatch ? threatMatch[1] : "Malware detected";

      return {
        isInfected: true,
        threatName: threatName,
        details: `Threat detected: ${threatName}`,
      };
    }

    // 其他錯誤
    console.error("ClamAV scan error:", error);
    return {
      isInfected: false,
      details: `Scan error: ${error.message}`,
    };
  }
}

/**
 * 將 ClamAV 結果轉換為威脅等級
 */
export function clamavResultToThreatLevel(
  result: ClamAVResult
): "safe" | "suspicious" | "dangerous" {
  if (!result.isInfected) {
    return "safe";
  }

  // 根據威脅名稱判斷危險等級
  const threatName = (result.threatName || "").toLowerCase();

  // 高危威脅
  if (
    threatName.includes("trojan") ||
    threatName.includes("ransomware") ||
    threatName.includes("backdoor") ||
    threatName.includes("rootkit") ||
    threatName.includes("worm")
  ) {
    return "dangerous";
  }

  // 中等威脅
  if (
    threatName.includes("pua") ||
    threatName.includes("adware") ||
    threatName.includes("pup") ||
    threatName.includes("potentially")
  ) {
    return "suspicious";
  }

  // 預設為危險
  return "dangerous";
}

/**
 * 掃描上傳的檔案
 */
export async function scanUploadedFile(
  fileName: string,
  fileBuffer: Buffer
): Promise<ClamAVResult> {
  // 建立臨時檔案（保留原始檔案副檔名）
  const tempDir = "/tmp";
  // 提取檔案副檔名，保持原始檔案類型
  const fileExtension = path.extname(fileName) || '.bin';
  const tempFileName = `scan_${Date.now()}_${Math.random().toString(36).substring(7)}${fileExtension}`;
  const tempFilePath = path.join(tempDir, tempFileName);

  try {
    // 寫入臨時檔案
    fs.writeFileSync(tempFilePath, fileBuffer);

    // 掃描檔案
    const result = await scanFileWithClamAV(tempFilePath);

    return result;
  } finally {
    // 清理臨時檔案
    try {
      if (fs.existsSync(tempFilePath)) {
        fs.unlinkSync(tempFilePath);
      }
    } catch (err) {
      console.error("Failed to delete temp file:", err);
    }
  }
}
