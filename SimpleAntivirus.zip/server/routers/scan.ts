import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import { createScanResult, getScanResultsByUserId, getScanHistoryByUserId, getScanResultById, createScanHistory } from "../db";
import { TRPCError } from "@trpc/server";

/**
 * Analyze file threat level using LLM
 */
async function analyzeFileThreat(fileName: string, fileSize: number, fileType: string): Promise<{
  threatLevel: "safe" | "suspicious" | "dangerous";
  description: string;
}> {
  const prompt = `You are a professional antivirus engine analyzer. Analyze the following file and determine its threat level.

File Information:
- Name: ${fileName}
- Size: ${fileSize} bytes
- Type: ${fileType}

Based on the file characteristics, respond with a JSON object containing:
1. "threatLevel": one of "safe", "suspicious", or "dangerous"
2. "description": a brief professional assessment (max 200 characters)

Consider these factors:
- Executable files (.exe, .bat, .cmd, .msi, .scr, .vbs) are higher risk
- Archive files (.zip, .rar, .7z) may contain unknown content
- Script files (.js, .ps1, .sh) require careful analysis
- Document files (.pdf, .doc, .xls) can contain embedded threats
- Media files (.jpg, .mp4, .mp3) are generally safer
- File size anomalies (very large or suspiciously small) may indicate issues

Respond ONLY with valid JSON, no additional text.`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are a security analysis AI that responds only with valid JSON.",
        },
        {
          role: "user",
          content: prompt,
        },
      ] as any,
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "threat_analysis",
          strict: true,
          schema: {
            type: "object",
            properties: {
              threatLevel: {
                type: "string",
                enum: ["safe", "suspicious", "dangerous"],
              },
              description: {
                type: "string",
              },
            },
            required: ["threatLevel", "description"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0]?.message.content;
    if (!content) {
      throw new Error("No response from LLM");
    }

    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const result = JSON.parse(contentStr);
    return {
      threatLevel: result.threatLevel,
      description: result.description,
    };
  } catch (error) {
    console.error("LLM analysis error:", error);
    // Fallback to basic heuristic analysis
    return analyzeFileHeuristic(fileName, fileSize, fileType);
  }
}

/**
 * Fallback heuristic analysis when LLM fails
 */
function analyzeFileHeuristic(
  fileName: string,
  fileSize: number,
  fileType: string
): {
  threatLevel: "safe" | "suspicious" | "dangerous";
  description: string;
} {
  const lowerName = fileName.toLowerCase();
  const lowerType = fileType.toLowerCase();

  // Dangerous patterns
  if (
    /\.(exe|bat|cmd|msi|scr|vbs|com|pif|pst)$/i.test(lowerName) ||
    lowerType.includes("executable") ||
    lowerType.includes("application/x-msdownload")
  ) {
    return {
      threatLevel: "dangerous",
      description: "Executable file detected. High risk of malware.",
    };
  }

  // Suspicious patterns
  if (
    /\.(zip|rar|7z|tar|gz|iso)$/i.test(lowerName) ||
    /\.(js|ps1|sh|bash|py|rb)$/i.test(lowerName) ||
    lowerType.includes("archive") ||
    lowerType.includes("script")
  ) {
    return {
      threatLevel: "suspicious",
      description: "Archive or script file. Requires careful inspection.",
    };
  }

  // Safe patterns
  if (
    /\.(jpg|jpeg|png|gif|mp3|mp4|pdf|doc|docx|xls|xlsx|txt)$/i.test(lowerName) ||
    lowerType.includes("image") ||
    lowerType.includes("audio") ||
    lowerType.includes("video") ||
    lowerType.includes("document")
  ) {
    return {
      threatLevel: "safe",
      description: "Common file type. No immediate threats detected.",
    };
  }

  // Default to suspicious for unknown types
  return {
    threatLevel: "suspicious",
    description: "Unknown file type. Recommend manual review.",
  };
}
export const scanRouter = router({
  /**
   * Scan a file and analyze threat level
   */
  scanFile: publicProcedure
    .input(
      z.object({
        fileName: z.string().min(1).max(255),
        fileSize: z.number().int().positive().max(1024 * 1024 * 1024), // Max 1GB
        fileType: z.string().min(1).max(100),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Generate anonymous user ID if not authenticated
      const userId = ctx.user?.id || Math.floor(Math.random() * 1000000000);

      // Analyze threat level
      const analysis = await analyzeFileThreat(
        input.fileName,
        input.fileSize,
        input.fileType
      );

      // Save scan result to database
      await createScanResult({
        userId: userId,
        fileName: input.fileName,
        fileSize: input.fileSize,
        fileType: input.fileType,
        threatLevel: analysis.threatLevel,
        threatDescription: analysis.description,
        scanTime: new Date(),
      });

      return {
        fileName: input.fileName,
        fileSize: input.fileSize,
        fileType: input.fileType,
        threatLevel: analysis.threatLevel,
        threatDescription: analysis.description,
        scanTime: new Date(),
      };
    }),

  /**
   * Get scan history for current user
   */
  getHistory: publicProcedure
    .input(z.object({ limit: z.number().int().positive().max(100).optional() }))
    .query(async ({ ctx, input }) => {
      const userId = ctx.user?.id || 0;
      const results = await getScanResultsByUserId(userId, input.limit || 50);
      return results;
    }),

  /**
   * Get scan session history
   */
  getSessionHistory: publicProcedure
    .input(z.object({ limit: z.number().int().positive().max(100).optional() }))
    .query(async ({ ctx, input }) => {
      const userId = ctx.user?.id || 0;
      const history = await getScanHistoryByUserId(userId, input.limit || 20);
      return history;
    }),

  /**
   * Get single scan result details
   */
  getResult: publicProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const userId = ctx.user?.id || 0;
      const result = await getScanResultById(input.id, userId);
      if (!result) {
        throw new TRPCError({ code: "NOT_FOUND" });
      }

      return result;
    }),

  /**
   * Create a scan session summary
   */
  createSession: publicProcedure
    .input(
      z.object({
        totalScans: z.number().int().positive(),
        safeCount: z.number().int().nonnegative(),
        suspiciousCount: z.number().int().nonnegative(),
        dangerousCount: z.number().int().nonnegative(),
        scanStartTime: z.date(),
        scanEndTime: z.date(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user?.id || Math.floor(Math.random() * 1000000000);

      // Determine overall risk level
      let overallRiskLevel: "safe" | "suspicious" | "dangerous" = "safe";
      if (input.dangerousCount > 0) {
        overallRiskLevel = "dangerous";
      } else if (input.suspiciousCount > 0) {
        overallRiskLevel = "suspicious";
      }

      await createScanHistory({
        userId: userId,
        totalScans: input.totalScans,
        safeCount: input.safeCount,
        suspiciousCount: input.suspiciousCount,
        dangerousCount: input.dangerousCount,
        overallRiskLevel,
        scanStartTime: input.scanStartTime,
        scanEndTime: input.scanEndTime,
      });

      return {
        overallRiskLevel,
      };
    }),
});
