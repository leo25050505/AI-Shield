import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { detectUrlThreat } from "../services/urlDetection";
import { createUrlDetectionResult, getUrlDetectionResults, getUrlDetectionByUrl } from "../db";

export const urlDetectionRouter = router({
  /**
   * Detect URL threats
   * Input: URL string
   * Output: Threat level, description, and categories
   */
  detectUrl: publicProcedure
    .input(
      z.object({
        url: z.string().url("Invalid URL format").min(1).max(2048),
      })
    )
    .mutation(async ({ input }) => {
      const { url } = input;
      
      // Check if URL was already scanned recently (within 24 hours)
      const cachedResult = await getUrlDetectionByUrl(url);
      if (cachedResult) {
        const oneDay = 24 * 60 * 60 * 1000;
        if (Date.now() - cachedResult.detectionTime.getTime() < oneDay) {
          return {
            url: cachedResult.url,
            threatLevel: cachedResult.threatLevel,
            threatDescription: cachedResult.threatDescription,
            threatCategories: cachedResult.threatCategories ? JSON.parse(cachedResult.threatCategories) : [],
            cached: true,
            detectionTime: cachedResult.detectionTime,
          };
        }
      }
      
      // Perform new detection
      const threatInfo = await detectUrlThreat(url);
      
      // Store result in database
      await createUrlDetectionResult({
        url,
        threatLevel: threatInfo.threatLevel,
        threatDescription: threatInfo.threatDescription,
        threatCategories: JSON.stringify(threatInfo.threatCategories),
        detectionSource: process.env.VIRUSTOTAL_API_KEY ? "virustotal" : "heuristic",
      });
      
      return {
        url,
        threatLevel: threatInfo.threatLevel,
        threatDescription: threatInfo.threatDescription,
        threatCategories: threatInfo.threatCategories,
        cached: false,
        detectionTime: new Date(),
      };
    }),

  /**
   * Get recent URL detection results
   */
  getHistory: publicProcedure
    .input(
      z.object({
        limit: z.number().int().min(1).max(100).default(50),
      })
    )
    .query(async ({ input }) => {
      const results = await getUrlDetectionResults(input.limit);
      
      return results.map((result) => ({
        id: result.id,
        url: result.url,
        threatLevel: result.threatLevel,
        threatDescription: result.threatDescription,
        threatCategories: result.threatCategories ? JSON.parse(result.threatCategories) : [],
        detectionSource: result.detectionSource,
        detectionTime: result.detectionTime,
      }));
    }),
});
