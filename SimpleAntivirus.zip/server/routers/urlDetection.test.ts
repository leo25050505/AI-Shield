import { describe, it, expect } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("urlDetection router", () => {
  describe("detectUrl", () => {
    it("should detect safe URLs", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.urlDetection.detectUrl({
        url: "https://www.google.com",
      });

      expect(result).toBeDefined();
      expect(result.url).toBe("https://www.google.com");
      expect(result.threatLevel).toBeDefined();
      expect(["safe", "suspicious", "dangerous"]).toContain(result.threatLevel);
      expect(result.threatDescription).toBeDefined();
      expect(result.threatCategories).toBeDefined();
      expect(Array.isArray(result.threatCategories)).toBe(true);
    }, { timeout: 30000 });

    it("should detect suspicious URLs with phishing patterns", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.urlDetection.detectUrl({
        url: "https://example.com/admin/login/verify",
      });

      expect(result).toBeDefined();
      expect(result.threatLevel).toBeDefined();
      expect(["safe", "suspicious", "dangerous"]).toContain(result.threatLevel);
    }, { timeout: 30000 });

    it("should detect dangerous URLs with suspicious patterns", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.urlDetection.detectUrl({
        url: "https://192.168.1.1/malware/trojan",
      });

      expect(result).toBeDefined();
      expect(result.threatLevel).toBeDefined();
      expect(["safe", "suspicious", "dangerous"]).toContain(result.threatLevel);
    }, { timeout: 30000 });

    it("should flag insecure HTTP URLs as suspicious", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.urlDetection.detectUrl({
        url: "http://example.com",
      });

      expect(result).toBeDefined();
      expect(result.threatLevel).toBe("suspicious");
      expect(result.threatDescription).toContain("HTTPS");
    }, { timeout: 30000 });

    it("should reject invalid URLs", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.urlDetection.detectUrl({
          url: "not-a-valid-url",
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        // Expected: Zod validation error for invalid URL format
        expect(error.code).toBe("BAD_REQUEST");
      }
    }, { timeout: 30000 });

    it("should allow anonymous users to detect URLs", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {
          protocol: "https",
          headers: {},
        } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = appRouter.createCaller(ctx);

      const result = await caller.urlDetection.detectUrl({
        url: "https://github.com",
      });

      expect(result).toBeDefined();
      expect(result.threatLevel).toBeDefined();
    }, { timeout: 30000 });
  });

  describe("getHistory", () => {
    it("should return URL detection history", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const results = await caller.urlDetection.getHistory({
        limit: 10,
      });

      expect(Array.isArray(results)).toBe(true);
      expect(results.length).toBeLessThanOrEqual(10);

      if (results.length > 0) {
        const result = results[0];
        expect(result.id).toBeDefined();
        expect(result.url).toBeDefined();
        expect(result.threatLevel).toBeDefined();
        expect(["safe", "suspicious", "dangerous"]).toContain(result.threatLevel);
        expect(result.threatDescription).toBeDefined();
        expect(Array.isArray(result.threatCategories)).toBe(true);
      }
    }, { timeout: 30000 });

    it("should respect limit parameter", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const results = await caller.urlDetection.getHistory({
        limit: 5,
      });

      expect(results.length).toBeLessThanOrEqual(5);
    }, { timeout: 30000 });
  });
});
