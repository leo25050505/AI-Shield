import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { scanUploadedFile, clamavResultToThreatLevel } from "../services/clamav";
import { createScanResult } from "../db";
import { TRPCError } from "@trpc/server";

export const uploadRouter = router({
  /**
   * 上傳並掃描檔案
   */
  uploadAndScan: publicProcedure
    .input(
      z.object({
        fileName: z.string().min(1).max(255),
        fileBuffer: z.string(), // base64 編碼的檔案內容
        fileType: z.string().min(1).max(100),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // 從 base64 解碼檔案
        const fileBuffer = Buffer.from(input.fileBuffer, 'base64');

        // 驗證檔案大小（1GB）
        if (fileBuffer.length > 1024 * 1024 * 1024) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "File size exceeds 1GB limit",
          });
        }

        // 使用 ClamAV 掃描檔案
        const clamavResult = await scanUploadedFile(
          input.fileName,
          fileBuffer
        );

        // 轉換為威脅等級
        const threatLevel = clamavResultToThreatLevel(clamavResult);

        // 生成用戶 ID（匿名用戶）
        const userId = ctx.user?.id || Math.floor(Math.random() * 1000000000);

        // 保存掃描結果到資料庫
        await createScanResult({
          userId: userId,
          fileName: input.fileName,
          fileSize: fileBuffer.length,
          fileType: input.fileType,
          threatLevel: threatLevel,
          threatDescription:
            clamavResult.threatName || clamavResult.details,
          scanTime: new Date(),
        });

        return {
          fileName: input.fileName,
          fileSize: fileBuffer.length,
          fileType: input.fileType,
          threatLevel: threatLevel,
          threatDescription:
            clamavResult.threatName || clamavResult.details,
          isInfected: clamavResult.isInfected,
          scanTime: new Date(),
        };
      } catch (error: any) {
        console.error("Upload and scan error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error.message || "Scan failed",
        });
      }
    }),
});
