import { describe, expect, it, vi } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("scan router", () => {
  describe("scanFile", () => {
    it("should analyze a safe file correctly", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.scan.scanFile({
        fileName: "document.pdf",
        fileSize: 1024 * 100, // 100KB
        fileType: "application/pdf",
      });

      expect(result).toHaveProperty("fileName", "document.pdf");
      expect(result).toHaveProperty("fileSize", 1024 * 100);
      expect(result).toHaveProperty("fileType", "application/pdf");
      expect(result).toHaveProperty("threatLevel");
      expect(result).toHaveProperty("threatDescription");
      expect(["safe", "suspicious", "dangerous"]).toContain(result.threatLevel);
    }, { timeout: 15000 });

    it("should detect dangerous executable files", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.scan.scanFile({
        fileName: "malware.exe",
        fileSize: 2048,
        fileType: "application/x-msdownload",
      });

      expect(result.threatLevel).toBe("dangerous");
      expect(result.threatDescription).toContain("executable");
    });

    it("should flag suspicious archive files", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.scan.scanFile({
        fileName: "archive.zip",
        fileSize: 5 * 1024 * 1024, // 5MB
        fileType: "application/zip",
      });

      expect(result.threatLevel).toBe("suspicious");
      expect(result.threatDescription).toContain("Archive");
    });

    it("should validate file size limit (1GB)", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.scan.scanFile({
          fileName: "huge.bin",
          fileSize: 2 * 1024 * 1024 * 1024, // 2GB - exceeds limit
          fileType: "application/octet-stream",
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.code).toBe("BAD_REQUEST");
      }
    });

    it("should allow anonymous users to scan files", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {
          protocol: "https",
          headers: {},
        } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = appRouter.createCaller(ctx);

      const result = await caller.scan.scanFile({
        fileName: "test.txt",
        fileSize: 100,
        fileType: "text/plain",
      });
      
      expect(result).toBeDefined();
      expect(result.threatLevel).toBeDefined();
      expect(["safe", "suspicious", "dangerous"]).toContain(result.threatLevel);
    });
  });

  describe("getHistory", () => {
    it("should allow anonymous users to view history", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {
          protocol: "https",
          headers: {},
        } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = appRouter.createCaller(ctx);

      const result = await caller.scan.getHistory({});
      expect(Array.isArray(result)).toBe(true);
    });

    it("should return array of scan results for authenticated users", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.scan.getHistory({ limit: 10 });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("createSession", () => {
    it("should calculate overall risk level correctly", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const startTime = new Date();
      const endTime = new Date(startTime.getTime() + 60000); // 1 minute later

      const result = await caller.scan.createSession({
        totalScans: 10,
        safeCount: 7,
        suspiciousCount: 2,
        dangerousCount: 1,
        scanStartTime: startTime,
        scanEndTime: endTime,
      });

      expect(result.overallRiskLevel).toBe("dangerous");
    });

    it("should set risk level to suspicious when no dangerous files", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const startTime = new Date();
      const endTime = new Date(startTime.getTime() + 60000);

      const result = await caller.scan.createSession({
        totalScans: 10,
        safeCount: 8,
        suspiciousCount: 2,
        dangerousCount: 0,
        scanStartTime: startTime,
        scanEndTime: endTime,
      });

      expect(result.overallRiskLevel).toBe("suspicious");
    });

    it("should set risk level to safe when all files are safe", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const startTime = new Date();
      const endTime = new Date(startTime.getTime() + 60000);

      const result = await caller.scan.createSession({
        totalScans: 10,
        safeCount: 10,
        suspiciousCount: 0,
        dangerousCount: 0,
        scanStartTime: startTime,
        scanEndTime: endTime,
      });

      expect(result.overallRiskLevel).toBe("safe");
    });
  });
});
