# GitHub 設定與自動構建 APK 指南

## 步驟 1：建立 GitHub 帳戶

1. 訪問 [https://github.com](https://github.com)
2. 點擊「Sign up」
3. 填寫電子郵件、密碼、用戶名
4. 驗證電子郵件

## 步驟 2：建立新倉庫

1. 登入 GitHub
2. 點擊右上角「+」→「New repository」
3. 填寫倉庫資訊：
   - **Repository name**：`AI-Shield`
   - **Description**：`AI極簡防護 - 防毒掃描應用`
   - **Visibility**：Public（公開）或 Private（私密）
   - **Initialize with README**：勾選
4. 點擊「Create repository」

## 步驟 3：配置本地 Git

在您的電腦上執行：

```bash
# 設定 Git 用戶名與郵箱
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# 生成 SSH 金鑰（可選，但推薦）
ssh-keygen -t ed25519 -C "your.email@example.com"

# 將公鑰新增到 GitHub
# 複製 ~/.ssh/id_ed25519.pub 的內容
# 在 GitHub Settings → SSH and GPG keys → New SSH key 中貼上
```

## 步驟 4：推送代碼到 GitHub

在 SimpleAntivirus 項目目錄中執行：

```bash
# 初始化 Git 倉庫（如果還未初始化）
git init

# 新增所有檔案
git add .

# 建立初始提交
git commit -m "Initial commit: AI Shield antivirus app"

# 新增遠端倉庫
git remote add origin https://github.com/YOUR_USERNAME/AI-Shield.git

# 推送到 GitHub
git branch -M main
git push -u origin main
```

## 步驟 5：驗證 GitHub Actions 工作流程

1. 在 GitHub 倉庫中進入「Actions」標籤
2. 您應該看到「Build APK」工作流程
3. 點擊最新的工作流程運行
4. 等待構建完成（通常 10-15 分鐘）

## 步驟 6：下載 APK

### 方式 1：從 Actions 下載（推薦）

1. 進入「Actions」標籤
2. 點擊最新的「Build APK」工作流程
3. 向下滾動找到「Artifacts」部分
4. 點擊「AI-Shield-APK」下載 APK 檔案

### 方式 2：從 Releases 下載

1. 進入「Releases」標籤
2. 點擊最新的 Release
3. 在「Assets」中下載 APK 檔案

## 步驟 7：安裝 APK 到 Android 設備

### 方式 1：使用 ADB（Android Debug Bridge）

```bash
# 連接 Android 設備到電腦
# 啟用開發者模式與 USB 偵錯

# 安裝 APK
adb install AI-Shield-APK/app-release.apk

# 啟動應用
adb shell am start -n com.aishield.antivirus/.MainActivity
```

### 方式 2：直接安裝

1. 將 APK 檔案複製到 Android 設備
2. 使用檔案管理器打開 APK 檔案
3. 點擊「安裝」
4. 允許安裝未知來源的應用

## 步驟 8：自動化構建觸發

### 自動觸發條件

工作流程會在以下情況自動構建：
- 推送到 `main` 分支
- 建立 Pull Request 到 `main` 分支
- 手動觸發（Actions 標籤中的「Run workflow」）

### 手動觸發構建

1. 進入「Actions」標籤
2. 點擊左側「Build APK」
3. 點擊「Run workflow」
4. 選擇分支
5. 點擊「Run workflow」

## 故障排除

### 問題 1：構建失敗

**症狀：** GitHub Actions 工作流程失敗

**解決方案：**
1. 點擊失敗的工作流程
2. 查看「Logs」中的錯誤訊息
3. 常見原因：
   - 依賴安裝失敗：執行 `pnpm install` 並推送
   - 構建失敗：檢查代碼編譯錯誤
   - 簽名問題：檢查 Gradle 配置

### 問題 2：APK 檔案過大

**症狀：** APK 檔案 > 100MB

**解決方案：**
- 啟用 ProGuard 代碼混淆
- 移除不必要的依賴
- 使用 App Bundle 而不是 APK

### 問題 3：無法安裝 APK

**症狀：** Android 設備顯示「應用未安裝」

**解決方案：**
- 檢查 Android 版本（最低 Android 7.0）
- 清除應用快取：`adb shell pm clear com.aishield.antivirus`
- 重新安裝 APK

## 版本管理

### 建立新版本

1. 更新 `app.json` 中的版本號：
```json
{
  "expo": {
    "version": "1.0.1",
    "android": {
      "versionCode": 2
    }
  }
}
```

2. 提交並推送：
```bash
git add app.json
git commit -m "Release v1.0.1"
git tag v1.0.1
git push origin main --tags
```

3. GitHub 會自動建立 Release 並上傳 APK

## 安全最佳實踐

### 1. 保護敏感資訊

不要在代碼中提交敏感資訊：
```bash
# 建立 .gitignore 檔案
echo "google-play-key.json" >> .gitignore
echo ".env" >> .gitignore
git add .gitignore
git commit -m "Add .gitignore"
```

### 2. 使用 GitHub Secrets

對於敏感資訊，使用 GitHub Secrets：
1. 進入倉庫「Settings」
2. 點擊「Secrets and variables」→「Actions」
3. 點擊「New repository secret」
4. 新增敏感資訊

在工作流程中使用：
```yaml
- name: Use secret
  env:
    MY_SECRET: ${{ secrets.MY_SECRET }}
  run: echo $MY_SECRET
```

### 3. 定期更新依賴

```bash
# 檢查過期依賴
pnpm outdated

# 更新依賴
pnpm update

# 推送更新
git add pnpm-lock.yaml
git commit -m "Update dependencies"
git push
```

## 常用 Git 命令

```bash
# 查看狀態
git status

# 查看提交歷史
git log

# 建立新分支
git checkout -b feature/new-feature

# 切換分支
git checkout main

# 合併分支
git merge feature/new-feature

# 刪除分支
git branch -d feature/new-feature

# 查看遠端倉庫
git remote -v

# 拉取最新代碼
git pull

# 推送代碼
git push
```

## 監控與分析

### GitHub Actions 統計

1. 進入「Actions」標籤
2. 查看工作流程運行歷史
3. 監控構建時間與成功率

### 應用統計

1. 進入「Insights」標籤
2. 查看倉庫統計
3. 監控代碼變更與貢獻者

## 支援資源

- **GitHub 文檔**：https://docs.github.com
- **GitHub Actions 文檔**：https://docs.github.com/en/actions
- **Git 教程**：https://git-scm.com/doc
- **Android 開發**：https://developer.android.com

---

**版本 1.0**
**最後更新：2026 年 4 月 16 日**
