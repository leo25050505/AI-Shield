import { useState, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Upload, Shield, AlertCircle, CheckCircle, Clock, LogOut, Globe } from "lucide-react";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

type ScanStatus = "idle" | "scanning" | "complete";
type ThreatLevel = "safe" | "suspicious" | "dangerous";

interface ScanResult {
  fileName: string;
  fileSize: number;
  fileType: string;
  threatLevel: ThreatLevel;
  threatDescription: string;
  scanTime: Date;
}

interface UrlDetectionResult {
  url: string;
  threatLevel: ThreatLevel;
  threatDescription: string;
  threatCategories: string[];
  detectionTime: Date;
}

export default function ScanPage() {
  const { user, isAuthenticated } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [scanStatus, setScanStatus] = useState<ScanStatus>("idle");
  const [urlScanStatus, setUrlScanStatus] = useState<ScanStatus>("idle");
  const [currentResult, setCurrentResult] = useState<ScanResult | null>(null);
  const [currentUrlResult, setCurrentUrlResult] = useState<UrlDetectionResult | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [urlInput, setUrlInput] = useState<string>("");

  const uploadAndScanMutation = trpc.upload.uploadAndScan.useMutation();
  const detectUrlMutation = trpc.urlDetection.detectUrl.useMutation();
  const getHistoryQuery = trpc.scan.getHistory.useQuery({ limit: 50 });
  const getUrlHistoryQuery = trpc.urlDetection.getHistory.useQuery({ limit: 50 });

  // Handle file selection
  const handleFileSelect = async (file: File) => {
    if (file.size > 1024 * 1024 * 1024) {
      toast.error("File size exceeds 1GB limit");
      return;
    }

    setScanStatus("scanning");
    setCurrentResult(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      
      // 使用更可靠的 base64 編碼方法
      let base64String = '';
      const chunkSize = 0x8000; // 32KB chunks
      for (let i = 0; i < uint8Array.length; i += chunkSize) {
        const chunk = uint8Array.subarray(i, i + chunkSize);
        base64String += String.fromCharCode.apply(null, Array.from(chunk));
      }
      base64String = btoa(base64String);

      const result = await uploadAndScanMutation.mutateAsync({
        fileName: file.name,
        fileBuffer: base64String,
        fileType: file.type || "application/octet-stream",
      });

      setCurrentResult({
        fileName: result.fileName,
        fileSize: result.fileSize,
        fileType: result.fileType,
        threatLevel: result.threatLevel,
        threatDescription: result.threatDescription,
        scanTime: new Date(result.scanTime),
      } as ScanResult);

      await getHistoryQuery.refetch();
      setScanStatus("complete");
      toast.success("Scan completed");
    } catch (error) {
      console.error("Scan error:", error);
      toast.error("Scan failed");
      setScanStatus("idle");
    }
  };

  // Handle URL detection
  const handleUrlDetection = async () => {
    if (!urlInput.trim()) {
      toast.error("Please enter a URL");
      return;
    }

    setUrlScanStatus("scanning");
    setCurrentUrlResult(null);

    try {
      const result = await detectUrlMutation.mutateAsync({
        url: urlInput,
      });

      setCurrentUrlResult({
        url: result.url,
        threatLevel: result.threatLevel,
        threatDescription: result.threatDescription || "No description available",
        threatCategories: result.threatCategories || [],
        detectionTime: new Date(result.detectionTime),
      });

      await getUrlHistoryQuery.refetch();
      setUrlScanStatus("complete");
      toast.success("URL scan completed");
    } catch (error) {
      console.error("URL scan error:", error);
      toast.error("URL scan failed");
      setUrlScanStatus("idle");
    }
  };

  // Handle drag and drop
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFileSelect(files[0]);
    }
  };

  const getThreatIcon = (level: ThreatLevel) => {
    switch (level) {
      case "safe":
        return <CheckCircle className="w-8 h-8 text-[oklch(0.55_0.2_142)]" />;
      case "suspicious":
        return <AlertCircle className="w-8 h-8 text-[oklch(0.65_0.2_38)]" />;
      case "dangerous":
        return <AlertCircle className="w-8 h-8 text-[oklch(0.65_0.2_0)]" />;
    }
  };

  const getThreatBadgeClass = (level: ThreatLevel) => {
    switch (level) {
      case "safe":
        return "badge-safe";
      case "suspicious":
        return "badge-suspicious";
      case "dangerous":
        return "badge-dangerous";
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = async () => {
    if (!isAuthenticated) return;
    try {
      await logoutMutation.mutateAsync();
      window.location.reload();
    } catch (error) {
      toast.error("Logout failed");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-[oklch(0.55_0.2_142)]" />
              <h1 className="text-3xl font-bold">AI極簡防護</h1>
            </div>
            <div>
              {isAuthenticated && (
                <div className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground">{user?.name}</span>
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    size="sm"
                    className="gap-2"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout
                  </Button>
                </div>
              )}
            </div>
          </div>
          <p className="text-muted-foreground mt-2">
            AI 驅動的極簡防毒掃描工具
          </p>
        </div>
      </header>

      <main className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Scan Panel */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="file" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="file" className="gap-2">
                  <Upload className="w-4 h-4" />
                  File Scan
                </TabsTrigger>
                <TabsTrigger value="url" className="gap-2">
                  <Globe className="w-4 h-4" />
                  URL Check
                </TabsTrigger>
              </TabsList>

              {/* File Scan Tab */}
              <TabsContent value="file" className="space-y-6">
                {/* Upload Area */}
                <Card className="p-8 border-border/50 bg-card/50 backdrop-blur-sm">
                  <div
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                      dragActive
                        ? "border-[oklch(0.55_0.2_142)] bg-[oklch(0.55_0.2_142)]/5"
                        : "border-border/50 hover:border-border"
                    }`}
                  >
                    <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-semibold mb-2">
                      Drop file here or click to select
                    </h3>
                    <p className="text-sm text-muted-foreground mb-6">
                      Support all file formats • Maximum size: 1GB
                    </p>
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={scanStatus === "scanning" || uploadAndScanMutation.isPending}
                      className="bg-[oklch(0.55_0.2_142)] hover:bg-[oklch(0.55_0.2_142)]/90 text-foreground"
                    >
                      {scanStatus === "scanning" || uploadAndScanMutation.isPending ? "Scanning..." : "Select File"}
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      className="hidden"
                      accept="*/*"
                      onChange={(e) => {
                        if (e.target.files?.[0]) {
                          handleFileSelect(e.target.files[0]);
                        }
                      }}
                    />
                  </div>
                </Card>

                {/* File Scan Result */}
                {currentResult && (
                  <Card className="p-8 border-border/50 bg-card/50 backdrop-blur-sm">
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0">
                        {scanStatus === "scanning" ? (
                          <div className="w-16 h-16 rounded-full bg-[oklch(0.65_0.15_217)]/10 flex items-center justify-center animate-pulse">
                            <Clock className="w-8 h-8 text-[oklch(0.65_0.15_217)]" />
                          </div>
                        ) : (
                          <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center">
                            {getThreatIcon(currentResult.threatLevel)}
                          </div>
                        )}
                      </div>

                      <div className="flex-1">
                        <h3 className="text-xl font-semibold mb-2">
                          {currentResult.fileName}
                        </h3>
                        <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                          <p>Size: {formatFileSize(currentResult.fileSize)}</p>
                          <p>Type: {currentResult.fileType}</p>
                          <p>
                            Scanned:{" "}
                            {currentResult.scanTime.toLocaleString()}
                          </p>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className={getThreatBadgeClass(currentResult.threatLevel)}>
                            {currentResult.threatLevel.charAt(0).toUpperCase() +
                              currentResult.threatLevel.slice(1)}
                          </span>
                          <p className="text-sm">
                            {currentResult.threatDescription}
                          </p>
                        </div>

                        {scanStatus === "scanning" && (
                          <div className="mt-4">
                            <Progress value={65} className="h-2" />
                            <p className="text-xs text-muted-foreground mt-2">
                              Scanning in progress...
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                )}
              </TabsContent>

              {/* URL Check Tab */}
              <TabsContent value="url" className="space-y-6">
                {/* URL Input Area */}
                <Card className="p-8 border-border/50 bg-card/50 backdrop-blur-sm">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Enter URL to check
                      </label>
                      <div className="flex gap-2">
                      <Input
                        type="url"
                        placeholder="https://example.com"
                        value={urlInput || ""}
                        onChange={(e) => setUrlInput(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === "Enter") {
                            handleUrlDetection();
                          }
                        }}
                        disabled={urlScanStatus === "scanning" || detectUrlMutation.isPending}
                        className="flex-1"
                      />
                        <Button
                          onClick={handleUrlDetection}
                          disabled={urlScanStatus === "scanning" || detectUrlMutation.isPending}
                          className="bg-[oklch(0.55_0.2_142)] hover:bg-[oklch(0.55_0.2_142)]/90 text-foreground"
                        >
                          {urlScanStatus === "scanning" || detectUrlMutation.isPending ? "Checking..." : "Check URL"}
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* URL Detection Result */}
                {currentUrlResult && (
                  <Card className="p-8 border-border/50 bg-card/50 backdrop-blur-sm">
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0">
                        {urlScanStatus === "scanning" ? (
                          <div className="w-16 h-16 rounded-full bg-[oklch(0.65_0.15_217)]/10 flex items-center justify-center animate-pulse">
                            <Clock className="w-8 h-8 text-[oklch(0.65_0.15_217)]" />
                          </div>
                        ) : (
                          <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center">
                            {getThreatIcon(currentUrlResult.threatLevel)}
                          </div>
                        )}
                      </div>

                      <div className="flex-1">
                        <h3 className="text-xl font-semibold mb-2 break-all">
                          {currentUrlResult.url}
                        </h3>
                        <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                          <p>
                            Checked:{" "}
                            {currentUrlResult.detectionTime.toLocaleString()}
                          </p>
                        </div>

                        <div className="flex items-center gap-3 mb-4">
                          <span className={getThreatBadgeClass(currentUrlResult.threatLevel)}>
                            {currentUrlResult.threatLevel.charAt(0).toUpperCase() +
                              currentUrlResult.threatLevel.slice(1)}
                          </span>
                          <p className="text-sm">
                            {currentUrlResult.threatDescription}
                          </p>
                        </div>

                        {currentUrlResult.threatCategories.length > 0 && (
                          <div className="mt-4">
                            <p className="text-sm font-medium mb-2">Threat Categories:</p>
                            <div className="flex flex-wrap gap-2">
                              {currentUrlResult.threatCategories.map((category) => (
                                <span
                                  key={category}
                                  className="px-2 py-1 text-xs rounded bg-background/50 border border-border/30"
                                >
                                  {category}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar - History */}
          <div className="lg:col-span-1">
            <Tabs defaultValue="files" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="files" className="text-xs">Files</TabsTrigger>
                <TabsTrigger value="urls" className="text-xs">URLs</TabsTrigger>
              </TabsList>

              {/* File History */}
              <TabsContent value="files">
                <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm sticky top-4">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Scan History
                  </h3>

                  <div className="space-y-3 max-h-[600px] overflow-y-auto">
                    {getHistoryQuery.data && getHistoryQuery.data.length > 0 ? (
                      getHistoryQuery.data.map((result, idx) => (
                        <div
                          key={idx}
                          className="p-3 rounded-lg bg-background/50 border border-border/30 hover:border-border/50 transition-colors cursor-pointer"
                        >
                          <div className="flex items-start gap-2">
                            <div
                              className={`threat-indicator threat-indicator-${result.threatLevel} flex-shrink-0 mt-1`}
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate">
                                {result.fileName}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {formatFileSize(result.fileSize)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(result.scanTime).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        No scan history yet
                      </p>
                    )}
                  </div>
                </Card>
              </TabsContent>

              {/* URL History */}
              <TabsContent value="urls">
                <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm sticky top-4">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Globe className="w-5 h-5" />
                    URL History
                  </h3>

                  <div className="space-y-3 max-h-[600px] overflow-y-auto">
                    {getUrlHistoryQuery.data && getUrlHistoryQuery.data.length > 0 ? (
                      getUrlHistoryQuery.data.map((result, idx) => (
                        <div
                          key={idx}
                          className="p-3 rounded-lg bg-background/50 border border-border/30 hover:border-border/50 transition-colors cursor-pointer"
                        >
                          <div className="flex items-start gap-2">
                            <div
                              className={`threat-indicator threat-indicator-${result.threatLevel} flex-shrink-0 mt-1`}
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate text-xs">
                                {result.url}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(result.detectionTime).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        No URL history yet
                      </p>
                    )}
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
}
