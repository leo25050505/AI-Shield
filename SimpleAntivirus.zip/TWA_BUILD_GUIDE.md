# TWA (Trusted Web Activity) 快速生成指南

## 什麼是 TWA？

TWA 是 Google 推薦的方式，將 PWA 包裝成原生 Android 應用，可以發佈到 Google Play Store。

---

## 🚀 快速開始

### 前置要求

1. **Node.js** - https://nodejs.org/
2. **Java JDK 11+** - https://www.oracle.com/java/technologies/downloads/
3. **Android SDK** - https://developer.android.com/studio
4. **Bubblewrap CLI** - 將在下面安裝

### 步驟 1：安裝 Bubblewrap

```bash
npm install -g @bubblewrap/cli
```

### 步驟 2：初始化 TWA 專案

```bash
bubblewrap init \
  --manifest https://simpleav-jjwqgsqi.manus.space/manifest.json \
  --package-id com.aishield.antivirus \
  --app-name "AI極簡防護" \
  --app-version 1.0.0
```

### 步驟 3：構建 AAB（推薦用於 Play Store）

```bash
bubblewrap build --aab
```

或構建 APK：

```bash
bubblewrap build
```

### 步驟 4：取得生成的檔案

- **AAB 檔案**：`./app-release.aab` （用於 Play Store）
- **APK 檔案**：`./app-release.apk` （用於直接安裝）

---

## 📤 上傳到 Google Play Store

1. 登入 [Google Play Console](https://play.google.com/console)
2. 選擇您的應用
3. 進入「版本」→「建立新版本」
4. 上傳 `app-release.aab` 檔案
5. 填寫版本信息
6. 提交審核

---

## 🔍 驗證 TWA 簽名

確保應用簽名正確：

```bash
bubblewrap validate
```

---

## 📝 常見設定

### 自訂應用名稱
```bash
bubblewrap init \
  --app-name "您的應用名稱"
```

### 自訂套件名稱
```bash
bubblewrap init \
  --package-id com.yourcompany.appname
```

### 自訂應用版本
```bash
bubblewrap init \
  --app-version 1.0.0
```

---

## ✅ 檢查清單

- [ ] Node.js 已安裝
- [ ] Java JDK 已安裝
- [ ] Android SDK 已安裝
- [ ] Bubblewrap 已安裝
- [ ] Manifest.json 已驗證
- [ ] AAB 已成功構建
- [ ] 簽名已驗證
- [ ] 準備上傳到 Play Store

---

## 📞 故障排除

### 錯誤：找不到 Java
```bash
# 設定 JAVA_HOME
export JAVA_HOME=/path/to/jdk
```

### 錯誤：找不到 Android SDK
```bash
# 設定 ANDROID_HOME
export ANDROID_HOME=/path/to/android-sdk
```

### 錯誤：Manifest 無效
確保 manifest.json 包含以下必要欄位：
- `name` - 應用名稱
- `short_name` - 簡短名稱
- `start_url` - 起始 URL
- `icons` - 應用圖標
- `display` - 顯示模式（standalone）

---

**更多資訊：** https://developer.chrome.com/docs/android/trusted-web-activity/
