# AI極簡防護 - APK 構建與 Google Play Store 發佈指南

## 概述

本指南將引導您使用 **EAS Build**（Expo Application Services）將 AI極簡防護 Web App 轉換為 Android APK，並發佈到 Google Play Store。

EAS Build 是一個雲端構建服務，無需本地 Android SDK 即可生成簽名的 APK。

---

## 第一步：準備工作

### 1.1 安裝必要工具

```bash
# 安裝 Expo CLI
npm install -g eas-cli

# 或使用 pnpm
pnpm add -g eas-cli
```

### 1.2 建立 Expo 帳戶

1. 訪問 [https://expo.dev](https://expo.dev)
2. 點擊「Sign Up」註冊帳戶
3. 驗證電子郵件

### 1.3 登入 EAS CLI

```bash
eas login
```

系統會提示您輸入 Expo 帳戶認證。

---

## 第二步：配置 Capacitor 與 Expo

### 2.1 初始化 Capacitor

在項目根目錄執行：

```bash
cd /home/ubuntu/SimpleAntivirus

# 初始化 Capacitor
npx cap init "AI極簡防護" "com.aishield.antivirus"
```

**參數說明：**
- `"AI極簡防護"`：應用名稱
- `"com.aishield.antivirus"`：應用包名（反向域名格式）

### 2.2 建立 app.json 配置

在項目根目錄建立 `app.json`：

```json
{
  "expo": {
    "name": "AI極簡防護",
    "slug": "ai-shield",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./client/public/favicon.svg",
    "userInterfaceStyle": "dark",
    "splash": {
      "image": "./client/public/favicon.svg",
      "resizeMode": "contain",
      "backgroundColor": "#0a0a0a"
    },
    "assetBundlePatterns": [
      "**/*"
    ],
    "ios": {
      "supportsTabletMode": true
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./client/public/favicon.svg",
        "backgroundColor": "#0a0a0a"
      },
      "package": "com.aishield.antivirus",
      "versionCode": 1
    },
    "web": {
      "favicon": "./client/public/favicon.svg"
    },
    "plugins": [
      [
        "expo-build-properties",
        {
          "android": {
            "minSdkVersion": 24
          }
        }
      ]
    ]
  }
}
```

### 2.3 建立 eas.json 配置

在項目根目錄建立 `eas.json`：

```json
{
  "build": {
    "preview": {
      "android": "preview"
    },
    "preview2": {
      "android": "preview"
    },
    "preview3": {
      "android": "preview"
    },
    "production": {
      "android": "production"
    }
  },
  "submit": {
    "production": {
      "android": {
        "serviceAccount": "google-play-key.json",
        "track": "internal"
      }
    }
  }
}
```

---

## 第三步：建立 Google Play Console 帳戶

### 3.1 註冊 Google Play Developer

1. 訪問 [https://play.google.com/console](https://play.google.com/console)
2. 點擊「Create account」
3. 支付 $25 USD 開發者費用
4. 完成帳戶設定

### 3.2 建立應用

1. 在 Google Play Console 中點擊「Create app」
2. 應用名稱：`AI極簡防護`
3. 預設語言：繁體中文
4. 應用類型：選擇「Tools」或「Utilities」
5. 內容分級：完成問卷
6. 隱私政策：新增隱私政策 URL

### 3.3 建立服務帳戶金鑰

1. 在 Google Play Console 中進入「Settings」
2. 選擇「API access」
3. 點擊「Create service account」
4. 按照指示在 Google Cloud Console 建立服務帳戶
5. 下載 JSON 金鑰檔案
6. 將檔案重命名為 `google-play-key.json` 並放在項目根目錄

---

## 第四步：生成簽名金鑰

### 4.1 使用 EAS 自動生成

```bash
eas build --platform android --type app-signing
```

EAS 會自動為您生成並管理簽名金鑰。

### 4.2 或手動生成（可選）

```bash
# 生成簽名金鑰
keytool -genkey -v -keystore ai-shield-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias ai-shield-key

# 將金鑰轉換為 PEM 格式（如需要）
keytool -exportcert -alias ai-shield-key -keystore ai-shield-key.jks | \
  openssl x509 -inform der -text -noout
```

---

## 第五步：構建 APK

### 5.1 構建預覽版本（測試）

```bash
eas build --platform android --profile preview
```

此命令將：
- 構建 APK 檔案
- 上傳到 EAS 伺服器
- 提供下載連結

### 5.2 構建生產版本（發佈）

```bash
eas build --platform android --profile production
```

此命令將生成簽名的 APK，可直接上傳到 Google Play Store。

### 5.3 監控構建進度

```bash
# 查看所有構建
eas build:list

# 查看特定構建詳情
eas build:view <BUILD_ID>
```

---

## 第六步：上傳到 Google Play Store

### 6.1 手動上傳

1. 在 Google Play Console 中進入應用
2. 選擇「Release」→「Production」
3. 點擊「Create new release」
4. 上傳 APK 檔案
5. 新增版本說明
6. 檢查內容分級
7. 點擊「Review release」
8. 點擊「Start rollout to production」

### 6.2 使用 EAS 自動發佈

```bash
eas submit --platform android --latest
```

此命令將自動：
- 上傳最新的 APK 到 Google Play Store
- 使用 `eas.json` 中的配置
- 需要 `google-play-key.json` 服務帳戶金鑰

---

## 第七步：應用審核與發佈

### 7.1 Google Play 審核流程

1. **初始審核**（1-3 小時）
   - Google 自動檢查應用安全性
   - 驗證隱私政策

2. **內容審核**（1-7 天）
   - 人工審核應用內容
   - 驗證應用功能

3. **發佈**
   - 審核通過後自動發佈到 Play Store
   - 可能需要 24-48 小時才能在所有地區顯示

### 7.2 常見審核問題

| 問題 | 解決方案 |
|------|--------|
| 隱私政策缺失 | 新增隱私政策 URL |
| 權限過多 | 移除不必要的權限 |
| 內容不清楚 | 完善應用描述與截圖 |
| 安全問題 | 確保 HTTPS 連接 |

---

## 第八步：版本更新

### 8.1 更新應用版本

編輯 `app.json`：

```json
{
  "expo": {
    "version": "1.0.1",
    "android": {
      "versionCode": 2
    }
  }
}
```

### 8.2 重新構建與發佈

```bash
# 構建新版本
eas build --platform android --profile production

# 發佈到 Play Store
eas submit --platform android --latest
```

---

## 故障排除

### 問題 1：構建失敗

**症狀：** `eas build` 命令失敗

**解決方案：**
```bash
# 清除快取
eas build:cache --platform android --clear

# 重新構建
eas build --platform android --profile production
```

### 問題 2：簽名金鑰錯誤

**症狀：** `Keystore was tampered with, or password was incorrect`

**解決方案：**
```bash
# 重新生成簽名金鑰
eas build --platform android --type app-signing
```

### 問題 3：Google Play 審核被拒

**症狀：** 應用在 Google Play 審核中被拒

**解決方案：**
1. 檢查審核反饋信息
2. 修改應用或隱私政策
3. 重新提交審核

---

## 安全最佳實踐

### 1. 保護簽名金鑰

```bash
# 不要將金鑰檔案提交到 Git
echo "google-play-key.json" >> .gitignore
echo "ai-shield-key.jks" >> .gitignore
```

### 2. 使用環境變數

```bash
# 設定 Google Play 金鑰路徑
export EAS_BUILD_PROFILE=production
export GOOGLE_PLAY_KEY_PATH=./google-play-key.json
```

### 3. 定期更新依賴

```bash
# 檢查依賴更新
pnpm outdated

# 更新依賴
pnpm update
```

---

## 監控與分析

### 1. Google Play Console 分析

- **安裝數**：應用下載統計
- **評分**：用戶評分與評論
- **崩潰率**：應用穩定性監控
- **效能**：電池、記憶體使用情況

### 2. Firebase 整合（可選）

```bash
# 安裝 Firebase
pnpm add firebase

# 配置 Firebase
# 在 client/src/main.tsx 中初始化 Firebase
```

---

## 發佈檢查清單

- [ ] 應用名稱與圖標正確
- [ ] 隱私政策已新增
- [ ] 內容分級已完成
- [ ] 應用描述清晰
- [ ] 截圖已上傳（至少 2 張）
- [ ] 版本號正確
- [ ] 簽名金鑰已配置
- [ ] Google Play 帳戶已驗證
- [ ] 服務帳戶金鑰已配置
- [ ] 測試版本已在設備上驗證

---

## 常用命令參考

```bash
# 登入 Expo
eas login

# 查看登入狀態
eas whoami

# 構建 APK
eas build --platform android --profile production

# 查看構建歷史
eas build:list

# 發佈到 Play Store
eas submit --platform android --latest

# 查看發佈歷史
eas submit:list

# 清除構建快取
eas build:cache --platform android --clear
```

---

## 支援資源

- **Expo 官方文檔**：https://docs.expo.dev
- **EAS Build 文檔**：https://docs.expo.dev/build/introduction/
- **Google Play Console 幫助**：https://support.google.com/googleplay/android-developer
- **Capacitor 文檔**：https://capacitorjs.com/docs

---

## 聯絡支援

如有任何問題，請：
1. 查看 Expo 官方文檔
2. 在 Expo 社群論壇提問
3. 聯絡 Google Play 支援團隊

---

**最後更新：2026 年 4 月 16 日**
