// server/_core/index.ts
import "dotenv/config";
import express2 from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";

// shared/const.ts
var COOKIE_NAME = "app_session_id";
var ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
var AXIOS_TIMEOUT_MS = 3e4;
var UNAUTHED_ERR_MSG = "Please login (10001)";
var NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

// server/db.ts
import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";

// drizzle/schema.ts
import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";
var users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull()
});
var scanResults = mysqlTable("scanResults", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileSize: int("fileSize").notNull(),
  // in bytes
  fileType: varchar("fileType", { length: 100 }).notNull(),
  fileHash: varchar("fileHash", { length: 64 }),
  // SHA-256 hash
  threatLevel: mysqlEnum("threatLevel", ["safe", "suspicious", "dangerous"]).notNull(),
  threatDescription: text("threatDescription"),
  scanTime: timestamp("scanTime").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var scanHistory = mysqlTable("scanHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  totalScans: int("totalScans").notNull(),
  safeCount: int("safeCount").notNull().default(0),
  suspiciousCount: int("suspiciousCount").notNull().default(0),
  dangerousCount: int("dangerousCount").notNull().default(0),
  overallRiskLevel: mysqlEnum("overallRiskLevel", ["safe", "suspicious", "dangerous"]).notNull(),
  scanStartTime: timestamp("scanStartTime").notNull(),
  scanEndTime: timestamp("scanEndTime").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var urlDetectionResults = mysqlTable("urlDetectionResults", {
  id: int("id").autoincrement().primaryKey(),
  url: varchar("url", { length: 2048 }).notNull(),
  threatLevel: mysqlEnum("threatLevel", ["safe", "suspicious", "dangerous"]).notNull(),
  threatDescription: text("threatDescription"),
  threatCategories: text("threatCategories"),
  // JSON array of threat types
  detectionSource: varchar("detectionSource", { length: 100 }).notNull(),
  // e.g., "google_safe_browsing"
  detectionTime: timestamp("detectionTime").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});

// server/_core/env.ts
var ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? ""
};

// server/db.ts
var _db = null;
async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}
async function upsertUser(user) {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values = {
      openId: user.openId
    };
    const updateSet = {};
    const textFields = ["name", "email", "loginMethod"];
    const assignNullable = (field) => {
      const value = user[field];
      if (value === void 0) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== void 0) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== void 0) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = /* @__PURE__ */ new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = /* @__PURE__ */ new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}
async function getUserByOpenId(openId) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return void 0;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}
async function createScanResult(result) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const inserted = await db.insert(scanResults).values(result);
  return inserted;
}
async function getScanResultsByUserId(userId, limit = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const results = await db.select().from(scanResults).where(eq(scanResults.userId, userId)).orderBy(desc(scanResults.scanTime)).limit(limit);
  return results;
}
async function getScanHistoryByUserId(userId, limit = 20) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const history = await db.select().from(scanHistory).where(eq(scanHistory.userId, userId)).orderBy(desc(scanHistory.scanEndTime)).limit(limit);
  return history;
}
async function createScanHistory(history) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const inserted = await db.insert(scanHistory).values(history);
  return inserted;
}
async function getScanResultById(id, userId) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(scanResults).where(eq(scanResults.id, id)).limit(1);
  if (result.length > 0 && result[0].userId !== userId) {
    throw new Error("Unauthorized");
  }
  return result.length > 0 ? result[0] : null;
}
async function createUrlDetectionResult(result) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const inserted = await db.insert(urlDetectionResults).values(result);
  return inserted;
}
async function getUrlDetectionResults(limit = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const results = await db.select().from(urlDetectionResults).orderBy(desc(urlDetectionResults.detectionTime)).limit(limit);
  return results;
}
async function getUrlDetectionByUrl(url) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(urlDetectionResults).where(eq(urlDetectionResults.url, url)).orderBy(desc(urlDetectionResults.detectionTime)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// server/_core/cookies.ts
function isSecureRequest(req) {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  return {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: isSecureRequest(req)
  };
}

// shared/_core/errors.ts
var HttpError = class extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "HttpError";
  }
};
var ForbiddenError = (msg) => new HttpError(403, msg);

// server/_core/sdk.ts
import axios from "axios";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }
  decodeState(state) {
    const redirectUri = atob(state);
    return redirectUri;
  }
  async getTokenByCode(code, state) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state)
    };
    const { data } = await this.client.post(
      EXCHANGE_TOKEN_PATH,
      payload
    );
    return data;
  }
  async getUserInfoByToken(token) {
    const { data } = await this.client.post(
      GET_USER_INFO_PATH,
      {
        accessToken: token.accessToken
      }
    );
    return data;
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  client;
  oauthService;
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(
      platforms.filter((p) => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, state) {
    return this.oauthService.getTokenByCode(code, state);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  parseCookies(cookieHeader) {
    if (!cookieHeader) {
      return /* @__PURE__ */ new Map();
    }
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(openId, options = {}) {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) || !isNonEmptyString(name)) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    let user = await getUserByOpenId(sessionUserId);
    if (!user) {
      try {
        const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
        await upsertUser({
          openId: userInfo.openId,
          name: userInfo.name || null,
          email: userInfo.email ?? null,
          loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
          lastSignedIn: signedInAt
        });
        user = await getUserByOpenId(userInfo.openId);
      } catch (error) {
        console.error("[Auth] Failed to sync user from OAuth:", error);
        throw ForbiddenError("Failed to sync user info");
      }
    }
    if (!user) {
      throw ForbiddenError("User not found");
    }
    await upsertUser({
      openId: user.openId,
      lastSignedIn: signedInAt
    });
    return user;
  }
};
var sdk = new SDKServer();

// server/_core/oauth.ts
function getQueryParam(req, key) {
  const value = req.query[key];
  return typeof value === "string" ? value : void 0;
}
function registerOAuthRoutes(app) {
  app.get("/api/oauth/callback", async (req, res) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }
      await upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect(302, "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}

// server/_core/systemRouter.ts
import { z } from "zod";

// server/_core/notification.ts
import { TRPCError } from "@trpc/server";
var TITLE_MAX_LENGTH = 1200;
var CONTENT_MAX_LENGTH = 2e4;
var trimValue = (value) => value.trim();
var isNonEmptyString2 = (value) => typeof value === "string" && value.trim().length > 0;
var buildEndpointUrl = (baseUrl) => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL(
    "webdevtoken.v1.WebDevService/SendNotification",
    normalizedBase
  ).toString();
};
var validatePayload = (input) => {
  if (!isNonEmptyString2(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required."
    });
  }
  if (!isNonEmptyString2(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required."
    });
  }
  const title = trimValue(input.title);
  const content = trimValue(input.content);
  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`
    });
  }
  return { title, content };
};
async function notifyOwner(payload) {
  const { title, content } = validatePayload(payload);
  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured."
    });
  }
  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured."
    });
  }
  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1"
      },
      body: JSON.stringify({ title, content })
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Failed to notify owner (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
      );
      return false;
    }
    return true;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError2 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async (opts) => {
  const { ctx, next } = opts;
  if (!ctx.user) {
    throw new TRPCError2({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});
var protectedProcedure = t.procedure.use(requireUser);
var adminProcedure = t.procedure.use(
  t.middleware(async (opts) => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError2({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({
      ctx: {
        ...ctx,
        user: ctx.user
      }
    });
  })
);

// server/_core/systemRouter.ts
var systemRouter = router({
  health: publicProcedure.input(
    z.object({
      timestamp: z.number().min(0, "timestamp cannot be negative")
    })
  ).query(() => ({
    ok: true
  })),
  notifyOwner: adminProcedure.input(
    z.object({
      title: z.string().min(1, "title is required"),
      content: z.string().min(1, "content is required")
    })
  ).mutation(async ({ input }) => {
    const delivered = await notifyOwner(input);
    return {
      success: delivered
    };
  })
});

// server/routers/scan.ts
import { z as z2 } from "zod";

// server/_core/llm.ts
var ensureArray = (value) => Array.isArray(value) ? value : [value];
var normalizeContentPart = (part) => {
  if (typeof part === "string") {
    return { type: "text", text: part };
  }
  if (part.type === "text") {
    return part;
  }
  if (part.type === "image_url") {
    return part;
  }
  if (part.type === "file_url") {
    return part;
  }
  throw new Error("Unsupported message content part");
};
var normalizeMessage = (message) => {
  const { role, name, tool_call_id } = message;
  if (role === "tool" || role === "function") {
    const content = ensureArray(message.content).map((part) => typeof part === "string" ? part : JSON.stringify(part)).join("\n");
    return {
      role,
      name,
      tool_call_id,
      content
    };
  }
  const contentParts = ensureArray(message.content).map(normalizeContentPart);
  if (contentParts.length === 1 && contentParts[0].type === "text") {
    return {
      role,
      name,
      content: contentParts[0].text
    };
  }
  return {
    role,
    name,
    content: contentParts
  };
};
var normalizeToolChoice = (toolChoice, tools) => {
  if (!toolChoice) return void 0;
  if (toolChoice === "none" || toolChoice === "auto") {
    return toolChoice;
  }
  if (toolChoice === "required") {
    if (!tools || tools.length === 0) {
      throw new Error(
        "tool_choice 'required' was provided but no tools were configured"
      );
    }
    if (tools.length > 1) {
      throw new Error(
        "tool_choice 'required' needs a single tool or specify the tool name explicitly"
      );
    }
    return {
      type: "function",
      function: { name: tools[0].function.name }
    };
  }
  if ("name" in toolChoice) {
    return {
      type: "function",
      function: { name: toolChoice.name }
    };
  }
  return toolChoice;
};
var resolveApiUrl = () => ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0 ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions` : "https://forge.manus.im/v1/chat/completions";
var assertApiKey = () => {
  if (!ENV.forgeApiKey) {
    throw new Error("OPENAI_API_KEY is not configured");
  }
};
var normalizeResponseFormat = ({
  responseFormat,
  response_format,
  outputSchema,
  output_schema
}) => {
  const explicitFormat = responseFormat || response_format;
  if (explicitFormat) {
    if (explicitFormat.type === "json_schema" && !explicitFormat.json_schema?.schema) {
      throw new Error(
        "responseFormat json_schema requires a defined schema object"
      );
    }
    return explicitFormat;
  }
  const schema = outputSchema || output_schema;
  if (!schema) return void 0;
  if (!schema.name || !schema.schema) {
    throw new Error("outputSchema requires both name and schema");
  }
  return {
    type: "json_schema",
    json_schema: {
      name: schema.name,
      schema: schema.schema,
      ...typeof schema.strict === "boolean" ? { strict: schema.strict } : {}
    }
  };
};
async function invokeLLM(params) {
  assertApiKey();
  const {
    messages,
    tools,
    toolChoice,
    tool_choice,
    outputSchema,
    output_schema,
    responseFormat,
    response_format
  } = params;
  const payload = {
    model: "gemini-2.5-flash",
    messages: messages.map(normalizeMessage)
  };
  if (tools && tools.length > 0) {
    payload.tools = tools;
  }
  const normalizedToolChoice = normalizeToolChoice(
    toolChoice || tool_choice,
    tools
  );
  if (normalizedToolChoice) {
    payload.tool_choice = normalizedToolChoice;
  }
  payload.max_tokens = 32768;
  payload.thinking = {
    "budget_tokens": 128
  };
  const normalizedResponseFormat = normalizeResponseFormat({
    responseFormat,
    response_format,
    outputSchema,
    output_schema
  });
  if (normalizedResponseFormat) {
    payload.response_format = normalizedResponseFormat;
  }
  const response = await fetch(resolveApiUrl(), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${ENV.forgeApiKey}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(
      `LLM invoke failed: ${response.status} ${response.statusText} \u2013 ${errorText}`
    );
  }
  return await response.json();
}

// server/routers/scan.ts
import { TRPCError as TRPCError3 } from "@trpc/server";
async function analyzeFileThreat(fileName, fileSize, fileType) {
  const prompt = `You are a professional antivirus engine analyzer. Analyze the following file and determine its threat level.

File Information:
- Name: ${fileName}
- Size: ${fileSize} bytes
- Type: ${fileType}

Based on the file characteristics, respond with a JSON object containing:
1. "threatLevel": one of "safe", "suspicious", or "dangerous"
2. "description": a brief professional assessment (max 200 characters)

Consider these factors:
- Executable files (.exe, .bat, .cmd, .msi, .scr, .vbs) are higher risk
- Archive files (.zip, .rar, .7z) may contain unknown content
- Script files (.js, .ps1, .sh) require careful analysis
- Document files (.pdf, .doc, .xls) can contain embedded threats
- Media files (.jpg, .mp4, .mp3) are generally safer
- File size anomalies (very large or suspiciously small) may indicate issues

Respond ONLY with valid JSON, no additional text.`;
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are a security analysis AI that responds only with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "threat_analysis",
          strict: true,
          schema: {
            type: "object",
            properties: {
              threatLevel: {
                type: "string",
                enum: ["safe", "suspicious", "dangerous"]
              },
              description: {
                type: "string"
              }
            },
            required: ["threatLevel", "description"],
            additionalProperties: false
          }
        }
      }
    });
    const content = response.choices[0]?.message.content;
    if (!content) {
      throw new Error("No response from LLM");
    }
    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const result = JSON.parse(contentStr);
    return {
      threatLevel: result.threatLevel,
      description: result.description
    };
  } catch (error) {
    console.error("LLM analysis error:", error);
    return analyzeFileHeuristic(fileName, fileSize, fileType);
  }
}
function analyzeFileHeuristic(fileName, fileSize, fileType) {
  const lowerName = fileName.toLowerCase();
  const lowerType = fileType.toLowerCase();
  if (/\.(exe|bat|cmd|msi|scr|vbs|com|pif|pst)$/i.test(lowerName) || lowerType.includes("executable") || lowerType.includes("application/x-msdownload")) {
    return {
      threatLevel: "dangerous",
      description: "Executable file detected. High risk of malware."
    };
  }
  if (/\.(zip|rar|7z|tar|gz|iso)$/i.test(lowerName) || /\.(js|ps1|sh|bash|py|rb)$/i.test(lowerName) || lowerType.includes("archive") || lowerType.includes("script")) {
    return {
      threatLevel: "suspicious",
      description: "Archive or script file. Requires careful inspection."
    };
  }
  if (/\.(jpg|jpeg|png|gif|mp3|mp4|pdf|doc|docx|xls|xlsx|txt)$/i.test(lowerName) || lowerType.includes("image") || lowerType.includes("audio") || lowerType.includes("video") || lowerType.includes("document")) {
    return {
      threatLevel: "safe",
      description: "Common file type. No immediate threats detected."
    };
  }
  return {
    threatLevel: "suspicious",
    description: "Unknown file type. Recommend manual review."
  };
}
var scanRouter = router({
  /**
   * Scan a file and analyze threat level
   */
  scanFile: publicProcedure.input(
    z2.object({
      fileName: z2.string().min(1).max(255),
      fileSize: z2.number().int().positive().max(1024 * 1024 * 1024),
      // Max 1GB
      fileType: z2.string().min(1).max(100)
    })
  ).mutation(async ({ ctx, input }) => {
    const userId = ctx.user?.id || Math.floor(Math.random() * 1e9);
    const analysis = await analyzeFileThreat(
      input.fileName,
      input.fileSize,
      input.fileType
    );
    await createScanResult({
      userId,
      fileName: input.fileName,
      fileSize: input.fileSize,
      fileType: input.fileType,
      threatLevel: analysis.threatLevel,
      threatDescription: analysis.description,
      scanTime: /* @__PURE__ */ new Date()
    });
    return {
      fileName: input.fileName,
      fileSize: input.fileSize,
      fileType: input.fileType,
      threatLevel: analysis.threatLevel,
      threatDescription: analysis.description,
      scanTime: /* @__PURE__ */ new Date()
    };
  }),
  /**
   * Get scan history for current user
   */
  getHistory: publicProcedure.input(z2.object({ limit: z2.number().int().positive().max(100).optional() })).query(async ({ ctx, input }) => {
    const userId = ctx.user?.id || 0;
    const results = await getScanResultsByUserId(userId, input.limit || 50);
    return results;
  }),
  /**
   * Get scan session history
   */
  getSessionHistory: publicProcedure.input(z2.object({ limit: z2.number().int().positive().max(100).optional() })).query(async ({ ctx, input }) => {
    const userId = ctx.user?.id || 0;
    const history = await getScanHistoryByUserId(userId, input.limit || 20);
    return history;
  }),
  /**
   * Get single scan result details
   */
  getResult: publicProcedure.input(z2.object({ id: z2.number().int().positive() })).query(async ({ ctx, input }) => {
    const userId = ctx.user?.id || 0;
    const result = await getScanResultById(input.id, userId);
    if (!result) {
      throw new TRPCError3({ code: "NOT_FOUND" });
    }
    return result;
  }),
  /**
   * Create a scan session summary
   */
  createSession: publicProcedure.input(
    z2.object({
      totalScans: z2.number().int().positive(),
      safeCount: z2.number().int().nonnegative(),
      suspiciousCount: z2.number().int().nonnegative(),
      dangerousCount: z2.number().int().nonnegative(),
      scanStartTime: z2.date(),
      scanEndTime: z2.date()
    })
  ).mutation(async ({ ctx, input }) => {
    const userId = ctx.user?.id || Math.floor(Math.random() * 1e9);
    let overallRiskLevel = "safe";
    if (input.dangerousCount > 0) {
      overallRiskLevel = "dangerous";
    } else if (input.suspiciousCount > 0) {
      overallRiskLevel = "suspicious";
    }
    await createScanHistory({
      userId,
      totalScans: input.totalScans,
      safeCount: input.safeCount,
      suspiciousCount: input.suspiciousCount,
      dangerousCount: input.dangerousCount,
      overallRiskLevel,
      scanStartTime: input.scanStartTime,
      scanEndTime: input.scanEndTime
    });
    return {
      overallRiskLevel
    };
  })
});

// server/routers/upload.ts
import { z as z3 } from "zod";

// server/services/clamav.ts
import { exec } from "child_process";
import { promisify } from "util";
import * as fs from "fs";
import * as path from "path";
var execAsync = promisify(exec);
async function scanFileWithClamAV(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      return {
        isInfected: false,
        details: "File not found"
      };
    }
    const { stdout, stderr } = await execAsync(`clamscan "${filePath}"`, {
      timeout: 3e4
      // 30 秒超時
    });
    const output = stdout + stderr;
    if (output.includes("FOUND")) {
      const threatMatch = output.match(/:\s*(.+?)\s+FOUND/);
      const threatName = threatMatch ? threatMatch[1] : "Unknown threat";
      return {
        isInfected: true,
        threatName,
        details: `Threat detected: ${threatName}`
      };
    }
    return {
      isInfected: false,
      details: "File is clean"
    };
  } catch (error) {
    if (error.code === 1) {
      const output = error.stdout || error.stderr || "";
      const threatMatch = output.match(/:\s*(.+?)\s+FOUND/);
      const threatName = threatMatch ? threatMatch[1] : "Malware detected";
      return {
        isInfected: true,
        threatName,
        details: `Threat detected: ${threatName}`
      };
    }
    console.error("ClamAV scan error:", error);
    return {
      isInfected: false,
      details: `Scan error: ${error.message}`
    };
  }
}
function clamavResultToThreatLevel(result) {
  if (!result.isInfected) {
    return "safe";
  }
  const threatName = (result.threatName || "").toLowerCase();
  if (threatName.includes("trojan") || threatName.includes("ransomware") || threatName.includes("backdoor") || threatName.includes("rootkit") || threatName.includes("worm")) {
    return "dangerous";
  }
  if (threatName.includes("pua") || threatName.includes("adware") || threatName.includes("pup") || threatName.includes("potentially")) {
    return "suspicious";
  }
  return "dangerous";
}
async function scanUploadedFile(fileName, fileBuffer) {
  const tempDir = "/tmp";
  const tempFileName = `scan_${Date.now()}_${Math.random().toString(36).substring(7)}.tmp`;
  const tempFilePath = path.join(tempDir, tempFileName);
  try {
    fs.writeFileSync(tempFilePath, fileBuffer);
    const result = await scanFileWithClamAV(tempFilePath);
    return result;
  } finally {
    try {
      if (fs.existsSync(tempFilePath)) {
        fs.unlinkSync(tempFilePath);
      }
    } catch (err) {
      console.error("Failed to delete temp file:", err);
    }
  }
}

// server/routers/upload.ts
import { TRPCError as TRPCError4 } from "@trpc/server";
var uploadRouter = router({
  /**
   * 上傳並掃描檔案
   */
  uploadAndScan: publicProcedure.input(
    z3.object({
      fileName: z3.string().min(1).max(255),
      fileBuffer: z3.string(),
      // base64 編碼的檔案內容
      fileType: z3.string().min(1).max(100)
    })
  ).mutation(async ({ ctx, input }) => {
    try {
      const fileBuffer = Buffer.from(input.fileBuffer, "base64");
      if (fileBuffer.length > 1024 * 1024 * 1024) {
        throw new TRPCError4({
          code: "BAD_REQUEST",
          message: "File size exceeds 1GB limit"
        });
      }
      const clamavResult = await scanUploadedFile(
        input.fileName,
        fileBuffer
      );
      const threatLevel = clamavResultToThreatLevel(clamavResult);
      const userId = ctx.user?.id || Math.floor(Math.random() * 1e9);
      await createScanResult({
        userId,
        fileName: input.fileName,
        fileSize: fileBuffer.length,
        fileType: input.fileType,
        threatLevel,
        threatDescription: clamavResult.threatName || clamavResult.details,
        scanTime: /* @__PURE__ */ new Date()
      });
      return {
        fileName: input.fileName,
        fileSize: fileBuffer.length,
        fileType: input.fileType,
        threatLevel,
        threatDescription: clamavResult.threatName || clamavResult.details,
        isInfected: clamavResult.isInfected,
        scanTime: /* @__PURE__ */ new Date()
      };
    } catch (error) {
      console.error("Upload and scan error:", error);
      throw new TRPCError4({
        code: "INTERNAL_SERVER_ERROR",
        message: error.message || "Scan failed"
      });
    }
  })
});

// server/routers/urlDetection.ts
import { z as z4 } from "zod";

// server/services/urlDetection.ts
import axios2 from "axios";
function detectUrlThreatHeuristic(url) {
  const lowerUrl = url.toLowerCase();
  const dangerousPatterns = [
    /bit\.ly|tinyurl|short\.link/i,
    // URL shorteners (often used for phishing)
    /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i,
    // IP addresses (suspicious)
    /[a-z0-9]{32,}/i
    // Long random strings (often malicious)
  ];
  const suspiciousPatterns = [
    /phishing|malware|trojan|virus|worm/i,
    /admin|login|signin|verify|confirm/i,
    // Common phishing keywords
    /download|install|update|plugin/i,
    /\.tk|\.ml|\.ga|\.cf/i
    // Free domain TLDs
  ];
  for (const pattern of dangerousPatterns) {
    if (pattern.test(lowerUrl)) {
      return {
        threatLevel: "dangerous",
        threatDescription: "URL contains suspicious patterns commonly associated with malware or phishing attacks",
        threatCategories: ["MALWARE", "PHISHING"]
      };
    }
  }
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(lowerUrl)) {
      return {
        threatLevel: "suspicious",
        threatDescription: "URL contains patterns that may indicate phishing or social engineering",
        threatCategories: ["PHISHING", "SOCIAL_ENGINEERING"]
      };
    }
  }
  if (!lowerUrl.startsWith("https://")) {
    return {
      threatLevel: "suspicious",
      threatDescription: "URL does not use HTTPS encryption - potential security risk",
      threatCategories: ["INSECURE_CONNECTION"]
    };
  }
  return {
    threatLevel: "safe",
    threatDescription: "URL appears to be safe based on heuristic analysis",
    threatCategories: []
  };
}
async function detectUrlThreatVirusTotal(url) {
  const apiKey = process.env.VIRUSTOTAL_API_KEY;
  if (!apiKey) {
    console.warn("[UrlDetection] VirusTotal API key not configured, using heuristic analysis");
    return detectUrlThreatHeuristic(url);
  }
  try {
    const response = await axios2.post(
      "https://www.virustotal.com/api/v3/urls",
      `url=${encodeURIComponent(url)}`,
      {
        headers: {
          "x-apikey": apiKey,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        timeout: 1e4
      }
    );
    const analysisId = response.data.data.id;
    const analysisResponse = await axios2.get(
      `https://www.virustotal.com/api/v3/analyses/${analysisId}`,
      {
        headers: { "x-apikey": apiKey },
        timeout: 1e4
      }
    );
    const stats = analysisResponse.data.data.attributes.stats;
    const maliciousCount = stats.malicious || 0;
    const suspiciousCount = stats.suspicious || 0;
    let threatLevel = "safe";
    let threatCategories = [];
    if (maliciousCount > 0) {
      threatLevel = "dangerous";
      threatCategories = ["MALWARE", "PHISHING", "TROJAN"];
    } else if (suspiciousCount > 0) {
      threatLevel = "suspicious";
      threatCategories = ["SUSPICIOUS"];
    }
    return {
      threatLevel,
      threatDescription: `VirusTotal scan: ${maliciousCount} malicious, ${suspiciousCount} suspicious detections`,
      threatCategories
    };
  } catch (error) {
    console.error("[UrlDetection] VirusTotal API error:", error);
    return detectUrlThreatHeuristic(url);
  }
}
async function detectUrlThreat(url) {
  try {
    new URL(url);
  } catch {
    return {
      threatLevel: "suspicious",
      threatDescription: "Invalid URL format",
      threatCategories: ["INVALID_URL"]
    };
  }
  if (process.env.VIRUSTOTAL_API_KEY) {
    return await detectUrlThreatVirusTotal(url);
  }
  return detectUrlThreatHeuristic(url);
}

// server/routers/urlDetection.ts
var urlDetectionRouter = router({
  /**
   * Detect URL threats
   * Input: URL string
   * Output: Threat level, description, and categories
   */
  detectUrl: publicProcedure.input(
    z4.object({
      url: z4.string().url("Invalid URL format").min(1).max(2048)
    })
  ).mutation(async ({ input }) => {
    const { url } = input;
    const cachedResult = await getUrlDetectionByUrl(url);
    if (cachedResult) {
      const oneDay = 24 * 60 * 60 * 1e3;
      if (Date.now() - cachedResult.detectionTime.getTime() < oneDay) {
        return {
          url: cachedResult.url,
          threatLevel: cachedResult.threatLevel,
          threatDescription: cachedResult.threatDescription,
          threatCategories: cachedResult.threatCategories ? JSON.parse(cachedResult.threatCategories) : [],
          cached: true,
          detectionTime: cachedResult.detectionTime
        };
      }
    }
    const threatInfo = await detectUrlThreat(url);
    await createUrlDetectionResult({
      url,
      threatLevel: threatInfo.threatLevel,
      threatDescription: threatInfo.threatDescription,
      threatCategories: JSON.stringify(threatInfo.threatCategories),
      detectionSource: process.env.VIRUSTOTAL_API_KEY ? "virustotal" : "heuristic"
    });
    return {
      url,
      threatLevel: threatInfo.threatLevel,
      threatDescription: threatInfo.threatDescription,
      threatCategories: threatInfo.threatCategories,
      cached: false,
      detectionTime: /* @__PURE__ */ new Date()
    };
  }),
  /**
   * Get recent URL detection results
   */
  getHistory: publicProcedure.input(
    z4.object({
      limit: z4.number().int().min(1).max(100).default(50)
    })
  ).query(async ({ input }) => {
    const results = await getUrlDetectionResults(input.limit);
    return results.map((result) => ({
      id: result.id,
      url: result.url,
      threatLevel: result.threatLevel,
      threatDescription: result.threatDescription,
      threatCategories: result.threatCategories ? JSON.parse(result.threatCategories) : [],
      detectionSource: result.detectionSource,
      detectionTime: result.detectionTime
    }));
  })
});

// server/routers.ts
var appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  scan: scanRouter,
  upload: uploadRouter,
  urlDetection: urlDetectionRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true
      };
    })
  })
  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

// server/_core/context.ts
async function createContext(opts) {
  let user = null;
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }
  return {
    req: opts.req,
    res: opts.res,
    user
  };
}

// server/_core/vite.ts
import express from "express";
import fs3 from "fs";
import { nanoid } from "nanoid";
import path3 from "path";
import { createServer as createViteServer } from "vite";

// vite.config.ts
import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs2 from "node:fs";
import path2 from "node:path";
import { defineConfig } from "vite";
import { vitePluginManusRuntime } from "vite-plugin-manus-runtime";
var PROJECT_ROOT = import.meta.dirname;
var LOG_DIR = path2.join(PROJECT_ROOT, ".manus-logs");
var MAX_LOG_SIZE_BYTES = 1 * 1024 * 1024;
var TRIM_TARGET_BYTES = Math.floor(MAX_LOG_SIZE_BYTES * 0.6);
function ensureLogDir() {
  if (!fs2.existsSync(LOG_DIR)) {
    fs2.mkdirSync(LOG_DIR, { recursive: true });
  }
}
function trimLogFile(logPath, maxSize) {
  try {
    if (!fs2.existsSync(logPath) || fs2.statSync(logPath).size <= maxSize) {
      return;
    }
    const lines = fs2.readFileSync(logPath, "utf-8").split("\n");
    const keptLines = [];
    let keptBytes = 0;
    const targetSize = TRIM_TARGET_BYTES;
    for (let i = lines.length - 1; i >= 0; i--) {
      const lineBytes = Buffer.byteLength(`${lines[i]}
`, "utf-8");
      if (keptBytes + lineBytes > targetSize) break;
      keptLines.unshift(lines[i]);
      keptBytes += lineBytes;
    }
    fs2.writeFileSync(logPath, keptLines.join("\n"), "utf-8");
  } catch {
  }
}
function writeToLogFile(source, entries) {
  if (entries.length === 0) return;
  ensureLogDir();
  const logPath = path2.join(LOG_DIR, `${source}.log`);
  const lines = entries.map((entry) => {
    const ts = (/* @__PURE__ */ new Date()).toISOString();
    return `[${ts}] ${JSON.stringify(entry)}`;
  });
  fs2.appendFileSync(logPath, `${lines.join("\n")}
`, "utf-8");
  trimLogFile(logPath, MAX_LOG_SIZE_BYTES);
}
function vitePluginManusDebugCollector() {
  return {
    name: "manus-debug-collector",
    transformIndexHtml(html) {
      if (process.env.NODE_ENV === "production") {
        return html;
      }
      return {
        html,
        tags: [
          {
            tag: "script",
            attrs: {
              src: "/__manus__/debug-collector.js",
              defer: true
            },
            injectTo: "head"
          }
        ]
      };
    },
    configureServer(server) {
      server.middlewares.use("/__manus__/logs", (req, res, next) => {
        if (req.method !== "POST") {
          return next();
        }
        const handlePayload = (payload) => {
          if (payload.consoleLogs?.length > 0) {
            writeToLogFile("browserConsole", payload.consoleLogs);
          }
          if (payload.networkRequests?.length > 0) {
            writeToLogFile("networkRequests", payload.networkRequests);
          }
          if (payload.sessionEvents?.length > 0) {
            writeToLogFile("sessionReplay", payload.sessionEvents);
          }
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ success: true }));
        };
        const reqBody = req.body;
        if (reqBody && typeof reqBody === "object") {
          try {
            handlePayload(reqBody);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
          return;
        }
        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });
        req.on("end", () => {
          try {
            const payload = JSON.parse(body);
            handlePayload(payload);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
        });
      });
    }
  };
}
var plugins = [react(), tailwindcss(), jsxLocPlugin(), vitePluginManusRuntime(), vitePluginManusDebugCollector()];
var vite_config_default = defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path2.resolve(import.meta.dirname, "client", "src"),
      "@shared": path2.resolve(import.meta.dirname, "shared"),
      "@assets": path2.resolve(import.meta.dirname, "attached_assets")
    }
  },
  envDir: path2.resolve(import.meta.dirname),
  root: path2.resolve(import.meta.dirname, "client"),
  publicDir: path2.resolve(import.meta.dirname, "client", "public"),
  build: {
    outDir: path2.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    host: true,
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1"
    ],
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/_core/vite.ts
async function setupVite(app, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    server: serverOptions,
    appType: "custom"
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path3.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );
      let template = await fs3.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app) {
  const distPath = process.env.NODE_ENV === "development" ? path3.resolve(import.meta.dirname, "../..", "dist", "public") : path3.resolve(import.meta.dirname, "public");
  if (!fs3.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app.use(express.static(distPath));
  app.use("*", (_req, res) => {
    res.sendFile(path3.resolve(distPath, "index.html"));
  });
}

// server/_core/index.ts
function isPortAvailable(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}
async function findAvailablePort(startPort = 3e3) {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}
async function startServer() {
  const app = express2();
  const server = createServer(app);
  app.use(express2.json({ limit: "50mb" }));
  app.use(express2.urlencoded({ limit: "50mb", extended: true }));
  registerOAuthRoutes(app);
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext
    })
  );
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
startServer().catch(console.error);
