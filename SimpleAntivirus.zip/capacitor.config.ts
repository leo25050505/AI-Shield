import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aishield.antivirus',
  appName: 'AI極簡防護',
  webDir: 'dist'
};

export default config;
